const express = require("express");
const path = require("path");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const { verifyToken, newAccessToken } = require('@platform_jewels/bassure-node/service/token')
const verifyUserService = require('@platform_jewels/bassure-node/service/verifyUser')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json')
const loggers = require('@platform_jewels/bassure-node/service/logger')
const config = require('./config/app_config.json')
const redisService = require('./service/redisService')
const tokenService = require("./service/authorize_service");
const { urlName, result, subOperation } = require("./config/app_config.json")
const loginService = require('./service/login_service');
const { operatorIdListService, operatorGetAllIdListService, operatorRiskBalanceService, operatorGetAllIdListNewService } = require("./service/operator_service");
const { blockedIpAddress } = require("./service/surveillance_service");
const { redisUserStatus } = require("./service/usermanagement_service");
const { validation } = require('./service/user_validation')

//Router
const operatorRouter = require('./routes/operator_router')
const permissionRouter = require('./routes/permission_router')
const betslitRouter = require("./routes/betslip_router");
const authenticaterouter = require('./routes/authenticate_router')
const ContentRouter = require('./routes/contentRoutes');
const surveillanceRouter = require('./routes/surveillance_router')
const multipleIpRouter = require('./routes/multipleip_router')
const searchRouter = require('./routes/search_router')
const userManagementRouter = require('./routes/usermanagement_router')

const app = express();

app.use(cors());
app.use(cookieParser());


// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, './build')));


redisUserStatus()

//
blockedIpAddress()

app.use('/authenticate/user/login', validation(), (req, res) => {
  loginService.userLoginService(req, res);
});

app.post('/authenticate/accesstoken/get', (req, res) => {
  newAccessToken(req, res, config.tokenValidity.access, config.tokenValidity.refresh)
})

app.use('/content', ContentRouter);

app.use('/operatordetails/:id', (req, res) => {
  operatorIdListService(req, res)
})

app.use('/operatorgetall/new', (req, res) => {
  operatorGetAllIdListService(req, res)
})

app.use('/operatorgetall', (req, res) => {
  operatorGetAllIdListNewService(req, res)
})
app.use('/stakerisk/balance/update', (req, res) => {
  operatorRiskBalanceService(req, res)
})

app.use(verifyToken)

app.use((req, res, next) => {
  verifyUserService.verifyUser(req, res, next, redisService.userStatus, config.response_messages.notFound)
})

app.use(urlName.permission, permissionRouter)

// app.use(tokenService.authorize)

app.use(async function (req, res, next) {
  loggers.infos({ file_name: config.fileName.app, method_name: `${req.originalUrl.split("/")[1]}`, method: `${req.method}`, userid: `${req.token.userId}`, operation: `${req.method}`, subOperation: subOperation.entry, result: result.success, label: '', errorcode: `` })
  next();
})

app.use('/authenticate', authenticaterouter)
app.use('/search', searchRouter)
app.use('/betslip', betslitRouter)
app.use('/usermanagement', userManagementRouter)
app.use('/surveillance', surveillanceRouter)
app.use('/multipleip', multipleIpRouter)
app.use('/operator', operatorRouter)

//appconfig -local
//config - platform

// catch 404 and forward to error handler
// error handler
app.use(function (err, req, res, next) {
  // console.log(err,"bbb");
  loggers.errors({ file_name: config.fileName.appJs, method_name: config.methodName.errorHandler, userid: ``, operation: ``, subOperation: ``, result: '', label: err.message, errorcode: err.status || 500 });
  // console.log(err.message,"ssssssssssssss");
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});


app.use(function (req, res, next) {
  res.status(200).send(
    cr.responseCb(
      cr.headerCb({ code: appConfig.response_code.url_error }),
      cr.bodyCb({ val: config.response_messages.urlError })
    )
  )
});

process.on('uncaughtException', function (err) {
  console.error((new Date).toUTCString() + ' uncaughtException:', err.message)
  console.error(err.stack)
  process.exit(1)
});


process.on('unhandledRejection', function (err) {
  console.error((new Date).toUTCString() + ' uncaughtException:', err.message)
  console.error(err.stack)
  process.exit(1)
});



module.exports = app;
