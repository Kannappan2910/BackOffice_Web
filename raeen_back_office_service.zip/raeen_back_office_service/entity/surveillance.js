class Surveillance {
    constructor(userId, parentId, ipAddress, comments, deviceId, blockedDate, ipStatus) {
        this.userId = userId;
        this.parentId = parentId;
        this.ipAddress = ipAddress;
        this.comments = comments;
        this.blockedDate = blockedDate;
        this.deviceId = deviceId;
        this.ipStatus = ipStatus;
    }
}
module.exports = { Surveillance }