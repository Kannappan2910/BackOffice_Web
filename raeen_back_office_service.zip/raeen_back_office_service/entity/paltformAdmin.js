class PlatformAdmin{
    constructor(adminId, operatorId, adminType, adminName, userId, password, createdBy, updatedBy, userStatus) {
        this.adminId = adminId
        this.adminName = adminName
        this.userId = userId
        this.userStatus = userStatus
    }
}
module.exports = { PlatformAdmin }