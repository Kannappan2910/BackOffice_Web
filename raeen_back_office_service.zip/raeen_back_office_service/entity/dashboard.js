
class Dashboard {
    constructor({ creditLimit, availableBalance, uplineBalance, downlineBalance }) {
        this.creditLimit = creditLimit
        this.availableBalance = availableBalance
        this.uplineBalance = uplineBalance
        this.downlineBalance = downlineBalance
    }
}

module.exports = { Dashboard }
