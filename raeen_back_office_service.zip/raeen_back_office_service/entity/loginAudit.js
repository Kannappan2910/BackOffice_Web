class LoginAudit{
    constructor(userId,parentId,fromdate,todate,auditType,Date,ip){
        this.userId=userId
        this.parentId=parentId
        this.fromdate=fromdate
        this.todate=todate
        this.auditType=auditType
        this.Date=Date
        this.ip=ip
    }
}
module.exports={LoginAudit}