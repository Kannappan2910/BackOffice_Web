
class OperatorAdmin {
    constructor(operatorId, adminId,betfairBalance,operatorName,onStake,onProfit,stakeStatus,profitStatus,appKey,userName,betFairPassword, contactNumber,addressLine1,addressLine2,addressLine3,city,postCode,adminName,userId, password, liable, credits, balance) {
        this.operatorId = operatorId
        this.operatorName = operatorName
        this.contactNumber = contactNumber
        this.addressLine1 = addressLine1
        this.addressLine2 = addressLine2
        this.addressLine3 = addressLine3
        this.city = city
        this.adminId = adminId
        this.postCode = postCode
        this.adminName = adminName
        this.userId = userId
        this.password = password
        this.liable = liable
        this.betFairPassword = betFairPassword
        this.userName = userName
        this.credits = credits
        this.balance = balance
        this.onStake = onStake
        this.onProfit= onProfit
        this.stakeStatus = stakeStatus
        this.profitStatus = profitStatus
        this.appKey = appKey
        this.betfairBalance = betfairBalance
    }
}
module.exports = { OperatorAdmin }