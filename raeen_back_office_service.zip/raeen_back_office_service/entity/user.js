class User {
    constructor(userId,userTypeLabel,netExposure,betfairPassword,betfairUserName,betfairAppkey,exposure, give, notes,credit, take, customerMaxCredit, smaMaxCredit, maMaxCredit, agentMaxCredit, balance, betfairBalance, addressLine1, addressLine2, city, postCode, initialLogin, childRole, userType, userStatus, operatorName, contactNumber, adminName, loginStatus, updatedBy, parentId, operatorId, lastLogin, token ) {
       this.userTypeLabel=userTypeLabel
        this.userId = userId;
        this.netExposure = netExposure
        this.betfairAppkey =betfairAppkey
        this.betfairUserName =betfairUserName
        this.betfairPassword = betfairPassword
        this.initialLogin = initialLogin;
        this.userType = userType;
        this.userStatus = userStatus;
        this.loginStatus = loginStatus;
        this.updatedBy = updatedBy;
        this.operatorId=operatorId
        this.parentId = parentId;
        this.operatorId = operatorId
        this.lastLogin = lastLogin
        this.token = token
        this.childRole = childRole
        this.operatorName = operatorName
        this.contactNumber = contactNumber
        this.adminName = adminName
        this.balance = balance
        this.addressLine1 = addressLine1
        this.addressLine2 = addressLine2
        this.city = city
        this.postCode = postCode
        this.betfairBalance = betfairBalance
        this.maMaxCredit = maMaxCredit
        this.agentMaxCredit = agentMaxCredit
        this.customerMaxCredit = customerMaxCredit
        this.exposure = exposure
        this.take = take
        this.give = give
        this.credit = credit
        this.notes = notes

    }

}
module.exports = { User }