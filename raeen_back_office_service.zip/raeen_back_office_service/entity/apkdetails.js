class Apk {
    constructor(footer, apkLink, apkLabel, apkDate) {
        this.footer = footer
        this.apkLink = apkLink
        this.apkDate = apkDate
        this.apkLabel = apkLabel
    }
}
module.exports = { Apk }