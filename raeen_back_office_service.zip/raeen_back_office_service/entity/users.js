class Users {
    constructor(userId,fullName,emailId,phoneNumber,address,city,pincode,notes,createdBy){
        this.userId = userId;
        this.fullName = fullName;
        this.emailId = emailId;
        this.phoneNumber = phoneNumber;
        this.address =address
        this.city = city
        this.pincode = pincode
        this.notes =notes
        this.createdBy=createdBy
    }

}
module.exports = {Users}