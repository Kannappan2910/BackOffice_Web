class Admin{
    constructor(adminId,operatorId,adminType,adminName,userId,password,createdBy,updatedBy,userStatus){
        this.adminId=adminId
        this.operatorId=operatorId
        this.adminType=adminType,
        this.adminName=adminName
        this.userId=userId
        this.password=password
        this.createdBy=createdBy
        this.updatedBy=updatedBy
        this.userStatus=userStatus
    }
}
module.exports={Admin}