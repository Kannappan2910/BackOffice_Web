class Agent {
    constructor(agentId,firstName, lastName,  contactNumber, type,emailId,userId,  password, liable,credits,balance,operatorId ) {
       this.agentId = agentId
        this.firstName = firstName
        this.lastName = lastName 
        this.contactNumber =contactNumber
        this.emailId =emailId
        this.userId = userId
        this.password = password
        this.liable = liable
        this.credits = credits
        this.balance = balance
        this.operatorId = operatorId
        this.type = type
    }
}

module.exports = {Agent}