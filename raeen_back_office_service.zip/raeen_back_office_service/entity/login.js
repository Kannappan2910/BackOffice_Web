class Login{
    constructor({id,userId,initialLogin,permissions,operatorId}){
        this.id = id;
        this.userId = userId;
        this.initialLogin = initialLogin;
        this.permissions = permissions;
        this.operatorId = operatorId
    }
}

module.exports = {Login}