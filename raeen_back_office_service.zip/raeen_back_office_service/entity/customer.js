
class Customer {
    constructor(customerId,firstName, lastName,  contactNumber, emailId,userId,  password, liable,credits,balance ) {
        this.customerId = customerId
        this.firstName = firstName
        this.lastName = lastName 
        this.contactNumber =contactNumber
        this.emailId =emailId
        this.userId = userId
        this.password = password
        this.liable = liable
        this.credits = credits
        this.balance = balance
    }
}

module.exports = {Customer}