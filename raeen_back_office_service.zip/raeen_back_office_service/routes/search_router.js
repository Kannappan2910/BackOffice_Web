const express = require('express');
const router = express.Router();
const { userSearchByIdService, userSearchByIdParentService, userSearchByIdParentCustomerService } = require('../service/usermanagement_service');


router.get('/byparent/getall', (req, res) => {
    userSearchByIdService(req, res)
})

router.get('/byallparent/getall', (req, res) => {
    userSearchByIdParentService(req, res)
})

router.get('/customer/getall', (req, res) => {
    userSearchByIdParentCustomerService(req, res)
})


module.exports = router;
