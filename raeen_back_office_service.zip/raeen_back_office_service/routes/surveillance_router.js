const express = require('express');
const router = express.Router();
const surveillanceService = require("../service/surveillance_service");
const {addIpAddressValidation} = require("../service/user_validation")

router.post('/addipaddress',
addIpAddressValidation(),
//yet to check
    (req, res) => {
        surveillanceService.blockIpAddressService(req, res)
    })

router.get('/blockedipaddress/:parentId', (req, res) => {
    surveillanceService.blockedIpaddressGetByparentIdService(req, res)
})

router.get('/search', (req, res) => {
    surveillanceService.searchByIpAddressService(req, res)
})

router.delete('/unblock/:ipaddress', (req, res) => {
    surveillanceService.unBlockIpAddress(req, res)
})




module.exports = router;