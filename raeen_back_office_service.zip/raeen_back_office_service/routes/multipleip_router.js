const express = require("express");
const router = express.Router();
const multipleIpService = require("../service/multipleip_service");


router.get('/search', (req, res) => {
    multipleIpService.getmultipleIpservice(req, res)
})

module.exports = router;