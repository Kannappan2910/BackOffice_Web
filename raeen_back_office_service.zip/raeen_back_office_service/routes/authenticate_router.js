
const express = require('express');
const router = express.Router();
const loginService = require('../service/login_service')
const { changePasswordService, resetPasswordService, passwordVerifyService } = require('../service/usermanagement_service');
const { changePassword,resetPassword,verifyPassword } = require('../service/user_validation');

router.put('/user/logout', (req, res) => {
    loginService.userLogoutService(req, res)
})

router.put('/password/change', changePassword(), (req, res) => {
    changePasswordService(req, res)
})

router.put('/password/reset',resetPassword(), (req, res) => {
    resetPasswordService(req, res)
})

router.post('/password/verify',
// verifyPassword(),
 (req, res) => {
    passwordVerifyService(req, res)
})

module.exports = router;