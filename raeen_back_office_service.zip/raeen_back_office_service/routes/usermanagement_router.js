const express = require('express');
const { userAddService, userGetByIdService, userGetAllService, userDeleteService, userUpdateService, dropDownService,  statusCheckService } = require('../service/usermanagement_service');
const { userValidation,userUpdateValidation} = require('../service/user_validation');
const { dashboardDataGetService } = require('../service/dashboard_service');
const { loginTypeDropDown, getLoginDetailsById, getAllLoginDetails, getAllLoginChildDetails } = require('../service/login_history_service');
const router = express.Router();

router.post('/add',
     userValidation(), 
    (req, res) => {
        userAddService(req, res)
    })

router.get('/get/:userId', (req, res) => {
    userGetByIdService(req, res)
})

router.get('/getall', async (req, res) => {
    userGetAllService(req, res)
})

router.delete('/delete', async (req, res) => {
    userDeleteService(req, res)
})

router.put("/update",userUpdateValidation(),
    (req, res) => {
        userUpdateService(req, res)

    })


    //dashboard
router.get('/statustype/getall', (req, res) => {
    dropDownService(req, res)
})

router.get('/status/get', (req, res) => {
    statusCheckService(req, res)
})

router.get('/statistic/getall', (req, res) => {
    dashboardDataGetService(req, res)
})

//user history

router.get('/historytype/getall', (req, res) => {
    loginTypeDropDown(req, res)
})

router.get('/history/get/:userId',(req,res)=>{
getLoginDetailsById(req,res)
})

router.post('/history/getall',
// fromdate and todate validation
(req,res)=>{
    getAllLoginDetails(req,res)
})


router.post('/history/child/getall',
// fromdate and todate validation
(req,res)=>{
    getAllLoginChildDetails(req,res)
})


module.exports = router;
