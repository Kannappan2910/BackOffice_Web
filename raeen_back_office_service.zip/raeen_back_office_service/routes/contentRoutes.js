var express = require('express');
var router = express.Router();
const betFairService = require('../service/contentService')
const validator_service = require("../service/validator_service");


router.post('/addContent', validator_service.contentValidation(), (req, res) => {
    return betFairService.addContentService(req, res)
});

router.put('/footer/update', validator_service.contentValidation(), (req, res) => {
    return betFairService.updateContentService(req, res)
});

router.get('/footer/get/:contentName', (req, res) => {
    return betFairService.getContentService(req, res)
});

router.get('/customer/footer/get', (req, res) => {
    return betFairService.getCustomerContentService(req, res)
});

router.put('/customer/footer/update',(req,res)=>{
    betFairService.updateCustomerContentService(req,res)
})

router.delete('/deleteContent/:contentName', (req, res) => {
    return betFairService.deleteContentService(req, res)
});



module.exports = router;
