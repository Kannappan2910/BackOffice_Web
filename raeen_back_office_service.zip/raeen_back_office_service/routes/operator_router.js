const express = require('express');
const { operatorAddService, operatorGetAllService, operatorGetByIdService, operatorIdListService, operatorUpdateService, operatorUpdateBalance, operatorGetBalance, operatorDashBoard, operatorSettle, operatorRiskBalanceService } = require('../service/operator_service');
const { operatorValidation, operatorUpdateValidation } = require('../service/operator_validation');
const router = express.Router();

router.post('/add', operatorValidation(),
    (req, res) => {
        operatorAddService(req, res)
    })

router.get('/getall', (req, res) => {
    operatorGetAllService(req, res)
})

router.get('/get/:userId', (req, res) => {
    operatorGetByIdService(req, res)
})

router.put('/update',
    operatorUpdateValidation(),
    (req, res) => {
        operatorUpdateService(req, res)
    })

router.get('betfair/balance/get', (req, res) => [
    operatorGetBalance(req, res)
])

router.put('/balance/update', (req, res) => {
    operatorUpdateBalance(req, res)
})

router.put('/settle/balance/update', (req, res) => {
    operatorSettle(req, res)
})

module.exports = router;