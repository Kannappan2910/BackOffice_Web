const express = require('express');
const router = express.Router();
const betslip = require('../service/betslip_service');
const {validateBetslipValues} = require('../service/betslip_validation')

router.get('/get/:id',(req,res)=>{
    betslip.betSlipGetById(req,res)
})

router.put('/update',validateBetslipValues(),(req,res)=>{
    betslip.updateBetSlip(req,res)
})

module.exports = router;