const express = require('express');
const router = express.Router();
const { permission, getPermission } = require('../service/permission')

router.get('/update', (req, res) => {
    permission(req, res)
})

router.get('/getpermission', (req, res) => {
    getPermission(req, res)
})


module.exports = router;
