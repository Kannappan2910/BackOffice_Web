let name = /^[A-Z][a-z]{2,20}$/

let email = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/

let contactNumber = /^\d{6,25}$/

let adminName = /^[A-Za-z\s]{2,20}$/

let userId = /^[A-Za-z0-9_@&]{2,15}$/

let passwords = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?\d)(?=.*?[!@#\$&*~]).{8,25}$/

let credits = /^\d{1,25}$/

let operatorId=/^\d{1,25}$/

let stack = /^\d{1,25}$/
 
let ipAddress1=/^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)\.?\b){4}$/

let ipAddress2=/^25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d$/

let operatorName = /^[A-Z][A-Za-z0-9_@.#&]*.{2,20}$/

let address1 = /^[A-Za-z0-9_@. =#&]*.{2,30}$/

let address2 = /^[A-Za-z0-9_@. =#&]*.{2,30}$/

let city = /^[A-Za-z]{2,25}$/

let postCode = /^\d{6,10}$/

let limit = /^\d{1,25}$/

let appkey = /^[A-Za-z0-9]{2,25}$/

let stakeRisks= /^[0-9]{1,25}$/

module.exports = {
    adminName,
    stakeRisks,
    appkey,
    limit,
    name,
    email,
    contactNumber,
    userId,
    passwords,
    credits,
    stack,
    operatorName,
    address1,
    address2,
    city,
    postCode,
    operatorId,
    ipAddress1,
    ipAddress2
}