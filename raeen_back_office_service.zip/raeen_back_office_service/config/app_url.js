// const raeenBaseUrl = `${process.env.RAEEN_SERVICE}`
// const settlementBaseUrl = `${process.env.SETTLEMENT_SERVICE}`

const raeenBaseUrl = `https://raeen.uat.bassure.in/betfair-odds`
const settlementBaseUrl = `https://raeen.uat.bassure.in/settlement`

const operatorCompetitionService = `${raeenBaseUrl}/competition/add`
const primaryOperatorIdService = `${raeenBaseUrl}/operator/add`
const betFairEventIdService = `${raeenBaseUrl}/raeen/eventTypeList`
const betFairBalanceService = `${raeenBaseUrl}/betfair/balance`
const betFairAccountStatementService = `${raeenBaseUrl}/betfair/accountStatement`
const settlementAddService = `${settlementBaseUrl}/usermanagement/account/create`
const settlementUpdateService = `${settlementBaseUrl}/usermanagement/account/update`
const settlementClosedService = `${settlementBaseUrl}/usermanagement/account/closed`
const settlementGetAllService = `${settlementBaseUrl}/usermanagement/account/getall`
const settlementGetByIdService = `${settlementBaseUrl}/usermanagement/account/get`

module.exports = {
    betFairBalanceService, settlementAddService, settlementUpdateService, settlementClosedService, settlementGetAllService,
    settlementGetByIdService, betFairAccountStatementService, betFairEventIdService, primaryOperatorIdService,
    operatorCompetitionService
}