const pool = require('../repo/db_connection');
const dbQuery = require('../repo/dbQuery')
const config = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger')
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const moment = require('moment');
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const errorHandling = require('../service/errorhandling_service')

const operatorAdminAddRepo = async (req, userType) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        const count = await client.query(dbQuery.getOperatorCountQuery, [])
        const operatorAdd = await client.query(dbQuery.operatorAdd, [
            req.body.operatorName,
            req.body.contactNumber,
            config.userstatus.active,
            req.body.addressLine1,
            req.body.addressLine2,
            req.body.city,
            req.body.countryCode,
            req.body.postCode,
            req.body.token.userId,
            req.body.betfairAppkey,
            req.body.betfairUserName,
            req.body.betfairPassword,
            req.body.adminName,
            req.body.credit
        ]);
        await client.query(dbQuery.insertOperatorQuery, [
            req.body.userId,
            req.body.password,
            userType,
            operatorAdd.rows[0].operator_id,
            moment().format('YYYY-MM-DD HH:mm:ss'),
            req.body.token.parentId,
            operatorAdd.rows[0].operator_id,
            true,
            config.userstatus.active,
            config.loginstatus.logout,
            req.body.notes
        ]);

        await client.query('commit')
        return [count.rowCount, operatorAdd.rows[0]]
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminAddRepo, userid: `${req.token.userId}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminAddRepo, userid: `${req.token.userId}`, operation: config.method.post, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        await client.query('ROLLBACK');
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorAdminAddRepo, userId: `${req.token.userId}`, operation: config.method.post})
    } finally {
        client.release();
    }
}

const operatorAdminDeleteRepo = async (id) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        const data = await client.query(dbQuery.deleteOperatorQuery, [
            id
        ])
        await client.query(dbQuery.deleteOperatorAdminQuery, [
            id
        ])
        await client.query('COMMIT')
        return data.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminDeleteRepo, userid: `${userId}`, operation: config.method.delete, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminDeleteRepo, userid: `${userId}`, operation: config.method.delete, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        await client.query('ROLLBACK');
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorAdminDeleteRepo, userId: `${userId}`, operation: config.method.delete})
        // errorHandler.handleError(error)
    } finally {
        client.release();
    }
}


const operatorAdminGetAllRepo = async (userStatus, userType, userId) => {
    try {
        const operatorAdmin = await pool.query(dbQuery.operatorAdminGetAll, [userStatus, userType]);
        return operatorAdmin.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminGetAllRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminGetAllRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorAdminGetAllRepo, userId: `${userId}`, operation: config.method.get})
    }

}


const operatorAdminGetByIdRepo = async (id) => {
    try {
        const operatorAdmin = await pool.query(dbQuery.operatorGetByIdQuery, [id])
        return operatorAdmin.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminGetByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminGetByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorAdminGetByIdRepo, userId: `${id}`, operation: config.method.get})
    }
}


const operatorUpdateRepo = async (body) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        await client.query(dbQuery.operatorUpdateQuery, [
            body.operatorId,
            body.operatorName,
            body.contactNumber,
            body.userStatus,
            body.addressLine1,
            body.addressLine2,
            body.city,
            body.postCode
        ])
        let data
        if (body.userStatus == config.userstatus.active) {
            data = await client.query(dbQuery.operatorUpdateActiveQuery, [
                body.userStatus,
                body.userId
            ])
        } else {
            data = await client.query(dbQuery.operatorUpdateInActiveQuery, [
                body.userStatus,
                body.operatorId
            ])
        }    
        await client.query('COMMIT')
        return data.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminUpdateRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorAdminUpdateRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        await client.query('ROLLBACK');
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorAdminUpdateRepo, userId: `${body.operatorId}`, operation: config.method.put})
        // errorHandler.handleError(error)
    } finally {
        client.release();
    }

}


const operatorIdListRepo = async (id) => {
    try {
        const result = await pool.query(dbQuery.operatorIdDetailQuery, [id])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorIdListRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorIdListRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorIdListRepo, userId: `${id}`, operation: config.method.get})
    }
}

const operatorGetAllIdListRepo = async () => {
    try {
        const result = await pool.query(dbQuery.operatorIdListQuery, [
        ])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorGetAllIdListRepo, userid: ``, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorGetAllIdListRepo, userid: ``, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorGetAllIdListRepo, userId: ``, operation: config.method.get})
    }
}

const operatorUpdateBalanceRepo = async () => {
    try {
        const result = await pool.query(dbQuery.operatorUpdateBalance, [
            body.operatorId,
            body.refId,
            body.amount
        ])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorUpdateBalanceRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorUpdateBalanceRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorUpdateBalanceRepo, userId: `${body.operatorId}`, operation: config.method.put})
    }
}

const operatorDeleteRepo = async (operatorId) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        const operatorDelete = dbQuery.operatorDelete
        const operatorAdminDelete = dbQuery.operatorAdminDelete
       const result = await client.query(operatorDelete, [
            operatorId
        ])
        await client.query(operatorAdminDelete, [
            operatorId
        ])
        await client.query('COMMIT')
        return result.rows[0]
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorSettleRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorSettleRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        await client.query('ROLLBACK');
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorSettleRepo, userId: `${body.operatorId}`, operation: config.method.put})
        // errorHandler.handleError(error)
    } finally {
        client.release();
    }
}



const operatorRiskBalanceRepo = async (opId, balance) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        const result = await client.query(dbQuery.operatorRiskBalance, [
            opId,
            balance
        ])
        await client.query('COMMIT')
        return result.rows
    } catch (error) {
        await client.query('ROLLBACK');
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorRiskBalanceRepo, userid: `${opId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorRiskBalanceRepo, userid: `${opId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorRiskBalanceRepo, userId: `${opId}`, operation: config.method.put})
    } finally {
        client.release();
    }
}


const operatorSettleRepo = async (body) => {
    const client = await pool.connect()
    try {
        await client.query('BEGIN')
        const updatedSettleBalance = dbQuery.operatorSettle
        const updatedBalance = await client.query(updatedSettleBalance, [
            body.amount,
            body.operatorId
        ])
        await client.query('COMMIT')
        return updatedBalance.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorSettleRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.operatorSettleRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        await client.query('ROLLBACK');
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.operatorSettleRepo, userId: `${body.operatorId}`, operation: config.method.put})
        // errorHandler.handleError(error)
    } finally {
        client.release();
    }
}

const opertorCompetitionData = async (operatorId, eventTypeId) => {
    try {
        const data = await pool.query(dbQuery.opertorCompetitionData, [
            operatorId,
            eventTypeId
        ])
        return data.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.operatorRepo, method_name: config.methodName.opertorCompetitionData, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.operatorRepo, method_name: config.methodName.opertorCompetitionData, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.operatorRepo, methodName: config.methodName.opertorCompetitionData, userId: `${operatorId}`, operation: config.method.get})
    }
}

module.exports = { operatorDeleteRepo,opertorCompetitionData, operatorRiskBalanceRepo, operatorSettleRepo, operatorUpdateBalanceRepo, operatorGetAllIdListRepo, operatorAdminAddRepo, operatorUpdateRepo, operatorAdminDeleteRepo, operatorAdminGetAllRepo, operatorAdminGetByIdRepo, operatorIdListRepo }
