const pool = require('./db_connection');
const dbQuery = require('./dbQuery');
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const logger = require('@platform_jewels/bassure-node/service/logger')
const entity = require('@platform_jewels/bassure-node/entity/logging_enum')
const config = require('../config/app_config.json')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const errorHandling = require('../service/errorhandling_service')


const betslipGetByIdRepo = async (id) => {
  try {
    const data = await pool.query(dbQuery.betslipGetById, [id]);
    return data.rows;
  } catch (error) {
    // errorHandler.handleError(error)
    // logger.warns({ file_name: config.fileName.betslipRepo, method_name: config.methodName.betslipGetByIdRepo, userid: `${id}`, operation:config.method.get, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.betslipRepo, method_name: config.methodName.betslipGetByIdRepo, userid: `${id}`, operation:config.method.get, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
    errorHandling.handleError({ error: error, fileName: config.fileName.betsliprepo, methodName: config.methodName.betslipGetByIdRepo, userId: `${id}`, operation: config.method.get })

  }
}

const betSlipUpdateRepo = async (body) => {
  try {
    const data = await pool.query(dbQuery.updateBetSlip, [
      body.customerId,
      body.stack1,
      body.stack2,
      body.stack3,
      body.stack4,
      body.plus1,
      body.plus2,
      body.plus3,
      body.plus4
    ]);
    return data.rows
  } catch (error) {
    // errorHandler.handleError(error)
    // logger.warns({ file_name: config.fileName.betslipRepo, method_name: config.methodName.betSlipUpdateRepo, userid: `${body.customerId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.betslipRepo, method_name: config.methodName.betSlipUpdateRepo, userid: `${body.customerId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    errorHandling.handleError({ error: error, fileName: config.fileName.betsliprepo, methodName: config.methodName.betSlipUpdateRepo, userId: `${body.customerId}`, operation: config.method.put })
  }
}


module.exports = { betslipGetByIdRepo, betSlipUpdateRepo }