const pool = require('./db_connection');
const dbQuery = require('./dbQuery');
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const logger = require('@platform_jewels/bassure-node/service/logger')
const { response_code } = require('@platform_jewels/bassure-node/config/app_conifg.json');
const date = require('date-and-time')
const now = new Date();
const time = date.format(now, 'YYYY-MM-DD HH:mm:ss')
const config = require('../config/app_config.json')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const errorHandling = require('../service/errorhandling_service')

const dashboardDataGetRepo = async (userId) => {
    try {
        const dashboardData = await pool.query(dbQuery.dashboradUsers, [userId]);
        return dashboardData.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.dashboardDataGetRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.dashboardDataGetRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        errorHandling.handleError({ error: error, fileName: config.fileName.dashboardDataGetRepo, methodName: config.methodName.dashboardDataGetRepo, userId: `${userId}`, operation: config.method.get })
        // errorHandler.handleError(error)
    }
}

const dashboardOperatorDataGetRepo = async (userId) => {
    try {
        const dashboardData = await pool.query(dbQuery.dashboardOperator, [userId]);
        return dashboardData.rows
    } catch (error) {
        errorHandling.handleError({ error: error, fileName: config.fileName.dashboardDataGetRepo, methodName: config.methodName.dashboardOperatorDataGetRepo, userId: `${userId}`, operation: config.method.get })
        // logger.warns({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.dashboardOperatorDataGetRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.dashboardOperatorDataGetRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
    }
}


const getRolehierarchy = async (type) => {
    try {
        const result = await pool.query(dbQuery.getRolehierarchy, [type])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.getRolehierarchy, userid: ``, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.dashboardDataGetRepo, method_name: config.methodName.getRolehierarchy, userid: ``, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        errorHandling.handleError({ error: error, fileName: config.fileName.dashboardDataGetRepo, methodName: config.methodName.getRolehierarchy, userId: ``, operation: config.method.get })
    }
}


module.exports = { dashboardDataGetRepo, dashboardOperatorDataGetRepo, getRolehierarchy }
