const config = require('../config/app_config.json')
const pool = require('./db_connection');
// const dbQuery = require('./db_queries');
const dbquery = require('./dbQuery')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const logger = require('@platform_jewels/bassure-node/service/logger')
const entity = require('@platform_jewels/bassure-node/entity/logging_enum');
const { query } = require('express');
const moment = require('moment');
const errorHandling = require('../service/errorhandling_service')

//getall
const blockedIpAddressGetByparentIdRepo = async (parentId, operatorId) => {
  try {
    const result = await pool.query(dbquery.blockedIpAddressGetByParentId, [config.ip_status.Block, parentId, operatorId]);
    return result.rows
  } catch (error) {
    // logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceGetByparentIdRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceGetByparentIdRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: config.fileName.surveillanceRepo, methodName: config.methodName.surveillanceGetByparentIdRepo, userId: `${operatorId}`, operation: config.method.get})
  }
}

// const unblockByIpAddressRepo = async (ipAddress) => {
//   try {
//     const result = await pool.query(`update ipaddress set ip_status=$1 where ip_address=$2 returning *`, [app_config.ip_status.Unblock, ipAddress]);
//     return result.rows
//   } catch (error) {
//     logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: ``, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
//     logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: ``, operation: config.method.post, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
//     errorHandler.handleError(error)
//   }
// }

// const blockByIpAddressRepo = async (body) => {
//   try {
//     const result = await pool.query(dbquery.blockByIpAddres, [config.ip_status.Block, body.comments, body.ipAddress, body.deviceId, time]);
//     return result.rows
//   } catch (error) {
//     logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
//     logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
//     errorHandler.handleError(error)
//   }
// }
//unblock
const unBlockIpAddress = async (ip) => {
  try {
    const result = await pool.query(dbquery.unblockByIpAddress, [
      ip
    ])
    return result.rows
  } catch (error) {
    // logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceunBlockIpAddressRepo, userid: ``, operation: config.method.delete, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceunBlockIpAddressRepo, userid: ``, operation: config.method.delete, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: config.fileName.surveillanceRepo, methodName: config.methodName.surveillanceunBlockIpAddressRepo, userId: ``, operation: config.method.delete})
  }
}
//block
const addIpAddressRepo = async (body) => {
  try {
    const result = await pool.query(dbquery.addIpAddress, [
      body.ipAddress,
      moment().format('YYYY-MM-DD HH:mm:ss'),
      config.ip_status.Block,
      body.comments,
      body.parentId,
      body.deviceId,
      body.operatorId
    ]);
    return result.rows;
  } catch (error) {
    // logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: config.fileName.surveillanceRepo, methodName: config.methodName.surveillanceAddRepo, userId: `${body.operatorId}`, operation: config.method.post})
  }
}

//search
const searchIpAddressRepo = async (ipAddress, parentId, operatorId) => {
  try {
    const data = ipAddress + "%";
    const result = await pool.query(dbquery.searchIpAddress, [data, parentId, operatorId]);
    return result.rows;
  } catch (error) {
    // logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceSearchIpAddressRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceSearchIpAddressRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: config.fileName.surveillanceRepo, methodName: config.methodName.surveillanceSearchIpAddressRepo, userId: `${operatorId}`, operation: config.method.get})
  }
}
//getall operator
const getAllIpAddress = async (operatorId) => {
  try {
    const result = await pool.query(dbquery.getAllIpAddress, [
      operatorId
    ])
    return result.rows
  } catch (error) {
    // logger.warns({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.surveillanceRepo, method_name: config.methodName.surveillanceAddRepo, userid: `${body.operatorId}`, operation: config.method.post, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    errorHandling.handleError({ error: error, fileName: config.fileName.surveillanceRepo, methodName: config.methodName.surveillanceAddRepo, userId: `${body.operatorId}`, operation: config.method.post})
  }
}

module.exports = { getAllIpAddress, unBlockIpAddress, blockedIpAddressGetByparentIdRepo, addIpAddressRepo, searchIpAddressRepo }