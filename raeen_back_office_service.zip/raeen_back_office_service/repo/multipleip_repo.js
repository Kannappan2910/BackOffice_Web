const config = require('../config/app_config.json')
const pool = require('./db_connection');
const dbQuery = require('./dbQuery');
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const logger = require('@platform_jewels/bassure-node/service/logger')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const errorHandling = require('../service/errorhandling_service')

const multipleIpGetBySearchRepo = async (ip, userId, fromdate, todate, parentId) => {
  try {
    let result;
    let data = ip + "%";
    let data1 = userId + "%";
    if (ip && userId && fromdate && todate) {
      result = await pool.query(dbQuery.multipleipuserIdfromtoparent, [
        data,
        data1,
        fromdate,
        todate
      ]);
    }
    else if (ip && fromdate && todate) {
      result = await pool.query(dbQuery.multipleipparentfromto, [data, fromdate, todate]);
    }
    else if (userId && fromdate && todate) {
      result = await pool.query(dbQuery.multipleuseridfromto, [data1, fromdate, todate]);
    }
    else {
      result = await pool.query(dbQuery.multipleip, [fromdate, todate]);
    }
    return result.rows;
  } catch (error) {
    // logger.warns({ file_name: config.fileName.multipleIpRepo, method_name: config.methodName.multipleIpGetBySearchRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name: config.fileName.multipleIpRepo, method_name: config.methodName.multipleIpGetBySearchRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: config.fileName.multipleIpRepo, methodName: config.methodName.multipleIpGetBySearchRepo, userId: `${userId}`, operation: config.method.get})
  }
}


module.exports = { multipleIpGetBySearchRepo }