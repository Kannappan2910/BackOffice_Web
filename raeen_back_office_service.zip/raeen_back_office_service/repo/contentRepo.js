const pool = require('./db_connection');
const dbQuery = require('./dbQuery');
const respTime = require('@platform_jewels/bassure-node/service/processTime')
const errorHandling = require('../service/errorhandling_service')
const config = require('../config/app_config.json')

const checkContentExistRepo = async (body) => {
    try {
        /* inserting query here */
        const checkQuery = await pool.query(dbQuery.checkContentExist, [
            body.contentName,
        ]);
        return checkQuery.rows;
    }
    catch (error) {
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.checkContentExistRepo, userId: ``, operation:'' })
    }
};



const addContentRepo = async (body) => {
    return respTime.processTimeLogging(async () => {
        try {
            /* inserting query here */
            const insertQuery = await pool.query(dbQuery.insertTransaction, [
                body.contentName,
                body.contentDetail,
            ]);
            return insertQuery.rows[0];
        }
        catch (error) {
            // errorHandler.handleError(error)
            errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.addContentRepo, userId: ``, operation:'' })

        }
    }, "addContentRepo")
};


const updateContentRepo = async (body) => {
    try {
        /* inserting query here */
        const updateQuery = await pool.query(dbQuery.updateContent, [
            body.contentName,
            body.contentDetail,
        ]);
        return updateQuery.rows[0];
    }
    catch (error) {
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.updateContentRepo, userId: ``, operation:'' })
    }
};

const getContentRepo = async (contentName) => {
    try {
        /* inserting query here */
        const getQuery = await pool.query(dbQuery.getContent, [
            contentName,
        ]);
        return getQuery.rows[0];
    }
    catch (error) {
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.getContentRepo, userId: ``, operation: '' })
    }
};

const getCustomerContentRepo = async () => {
    const client = await pool.connect()
    try {
        /* inserting query here */
        const getQuery = await client.query(dbQuery.getCustomerContent, [
        ]);
        await client.query('commit')
        return getQuery.rows;
    }
    catch (error) {
        await client.query('ROLLBACK');
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.getCustomerContentRepo, userId: ``, operation: '' })
    } finally {
        client.release();
    }
};

const deleteContentRepo = async (customerName) => {
    try {
        /* inserting query here */
        const getQuery = await pool.query(dbQuery.deleteContent, [
            customerName,
        ]);
        return getQuery.rowCount;
    }
    catch (error) {
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.deleteContentRepo, userId: ``, operation:'' })
    }
};


const updateCustomerContentRepo = async (body) => {
    const client = await pool.connect()
    try {
        /* inserting query here */
        const getQuery = await client.query(dbQuery.updateCustomerContent, [
            body.apkLink,
            body.lastUpdated
        ]);
        await client.query('commit')
        return getQuery.rows;
    }
    catch (error) {
        await client.query('ROLLBACK');
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.contentRepo, methodName: config.methodName.updateCustomerContentRepo, userId: ``, operation: '' })
    } finally {
        client.release();
    }
};


module.exports = {
    updateCustomerContentRepo,
    checkContentExistRepo,
    addContentRepo,
    updateContentRepo,
    getContentRepo,
    deleteContentRepo,
    getCustomerContentRepo
}
