const pool = require('../repo/db_connection');
const dbQuery = require('../repo/dbQuery')
const config = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger')
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const moment = require('moment');
const errorHandling = require('../service/errorhandling_service')

const addUserCredentialRepo = async (userId, password, userType, createdBy, parentId, operatorId, notes) => {
    let client = await pool.connect();
    try {
        await client.query('BEGIN')
        const result = await client.query(dbQuery.userAddQuery, [
            userId,
            password,
            userType,
            createdBy,
            parentId,
            operatorId,
            true,
            config.userstatus.active,
            config.loginstatus.logout,
            notes,
            moment().format('YYYY-MM-DD HH:mm:ss')
        ])
        if (userType == config.userType.customer) {
            await client.query(dbQuery.betslipAddQuery, [
                userId,
                config.betslip.stack1,
                config.betslip.stack2,
                config.betslip.stack3,
                config.betslip.stack4,
                config.betslip.plus1,
                config.betslip.plus2,
                config.betslip.plus3,
                config.betslip.plus4
            ])

        }
        await client.query('COMMIT')
        return result.rows[0]
    }
    catch (error) {
        await client.query('ROLLBACK');
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.addUserCredentialRepo, userid: `${createdBy}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.duplication });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.addUserCredentialRepo, userid: `${createdBy}`, operation: config.method.post, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.addUserCredentialRepo, userId: `${createdBy}`, operation: config.method.post})
    } finally {
        client.release();
    }
}

const agentAdd = async (body) => {
    let client = await pool.connect();
    try {
        await client.query('BEGIN')
        const updatedBalance = await client.query(dbQuery.addOperatorBalanceQuery, [
            body.operatorId,
            body.credit
        ])
        await client.query('COMMIT')
        return updatedBalance.rows
    } catch (error) {
        await client.query('ROLLBACK')
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.agentAddRepo, userid: `${body.token.userId}`, operation: config.method.post, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.agentAddRepo, userid: `${body.token.userId}`, operation: config.method.post, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.agentAddRepo, userId: `${body.token.userId}`, operation: config.method.post})
    } finally {
        client.release();
    }
}


const agentUpdate = async (body) => {
    let client = await pool.connect();
    try {
        await client.query('BEGIN')
        const updatedBalance = await client.query(dbQuery.updateOperatorBalanceQuery, [
            body.operatorId,
            body.addedCredit
        ])
        await client.query('COMMIT')
        return updatedBalance.rows
    } catch (error) {
        await client.query('ROLLBACK')
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.agentUpdateRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.agentUpdateRepo, userid: `${body.operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.agentUpdateRepo, userId: `${body.operatorId}`, operation: config.method.put})
    } finally {
        client.release();
    }
}

const userDeleteRepo = async (userId, userType) => {
    let client = await pool.connect();
    try {
        await client.query('BEGIN')
        const result = await client.query(dbQuery.deleteUserQuery, [
            userId
        ])
        if (userType == config.userType.agent) {
            await client.query(dbQuery.deleteBetSlipQuery, [
                userId
            ])
        }
        await client.query('COMMIT')
        return result.rows
    } catch (error) {
        await client.query('ROLLBACK')
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userDeleteRepo, userid: `${userId}`, operation: config.method.delete, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userDeleteRepo, userid: `${userId}`, operation: config.method.delete, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.userDeleteRepo, userId: `${userId}`, operation: config.method.delete})
    } finally {
        client.release();
    }

}

const userGetByIdRepo = async (userId) => {
    try {
        let result = await pool.query(dbQuery.userGetByIdQuery, [userId])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userGetByIdRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userGetByIdRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.userGetByIdRepo, userId: `${userId}`, operation: config.method.get})
    }
}


const userGetAllRepo = async (userStatus, createdBy, userType) => {
    try {
        let result
        if (userStatus == config.userstatus.active) {
            result = await pool.query(dbQuery.userGetAllActiveQuery, [userStatus, createdBy, userType])
        } else {
            result = await pool.query(dbQuery.userGetAllInActiveQuery, [config.userstatus.active, createdBy])
        }
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userGetAllRepo, userid: ``, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userGetAllRepo, userid: ``, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.userGetAllRepo, userId: `${userId}`, operation: config.method.get})
    }
}


const changePasswordRepo = async (userId, password) => {
    try {
        const result = await pool.query(dbQuery.userChangePasswordQuery, [userId, password, false])
        return result
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.changePasswordRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.changePasswordRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.changePasswordRepo, userId: `${userId}`, operation: config.method.put})

    }
}


const resetPasswordRepo = async (userId, password) => {
    try {
        const result = await pool.query(dbQuery.userResetPasswordQuery, [userId, password])
        return result
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.resetPasswordRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.resetPasswordRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.resetPasswordRepo, userId: `${userId}`, operation: config.method.put})

    }
}

const updateActiveCredentialsRepo = async (userId, userStatus, notes, updatedBy) => {
    try {
        const result = await pool.query(dbQuery.userUpdateActiveQuery, [
            userId,
            userStatus,
            notes,
            updatedBy,
            moment().format('YYYY-MM-DD HH:mm:ss')
        ])
        return result.rows[0];
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.updateActiveCredentialsRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.updateActiveCredentialsRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: `${error.message}`, label: ``, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.updateActiveCredentialsRepo, userId: `${userId}`, operation: config.method.put})
    }
}

const updateInActiveCredentialsRepo = async (userId, userStatus, notes, updatedBy) => {
    try {
        const result = await pool.query(dbQuery.updateInActiveCredentials, [
            userId,
            userStatus,
            notes,
            updatedBy,
            moment().format('YYYY-MM-DD HH:mm:ss')
        ]);
        return result.rows;
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.updateInActiveCredentialsRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.updateInActiveCredentialsRepo, userid: `${userId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.updateInActiveCredentialsRepo, userId: `${userId}`, operation: config.method.put})
    }
}

const getRole = async (role) => {
    try {
        const result = await pool.query(dbQuery.getRoleQuery, [role])
        return result.rows[0].role_name
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getRole, userid: ``, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getRole, userid: ``, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getRole, userId: ``, operation: config.method.get})
    }
}

const userSearchByIdRepo = async (value, id, status) => {
    try {
        const data = value + "%";
        const searchQuery = status == config.userstatus.active ? dbQuery.userSearchByIdQuery + `and user_status = '${status}'` : dbQuery.userSearchByIdQuery + ` and user_status not in ('ACTIVE')`
        const result = await pool.query(searchQuery, [data, id]);
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userSearchByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.userSearchByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.userSearchByIdRepo, userId: `${id}`, operation: config.method.get})
    }
}

const operatorSearchByIdRepo = async (value, id, status, userType) => {
    try {
        const data = value + "%";
        const searchQuery = status == config.userstatus.active ? dbQuery.operatorSearchByIdQuery + `and user_status = '${status}'` : dbQuery.operatorSearchByIdQuery + ` and user_status not in ('ACTIVE')`
        const result = await pool.query(searchQuery, [data, id, userType]);
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.operatorSearchByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.operatorSearchByIdRepo, userid: `${id}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.operatorSearchByIdRepo, userId: `${id}`, operation: config.method.get})
    }
}

const getAllUser = async (createdBy) => {
    try {
        const result = await pool.query(dbQuery.getAllUserQuery, [createdBy])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserRepo, userid: `${createdBy}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserRepo, userid: `${createdBy}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getAllUserRepo, userId: `${createdBy}`, operation: config.method.get})
    }
}
//user status
const userStatusRepo = async (userId) => {
    try {
        const result = await pool.query(dbQuery.loginUserQuery, [userId])
        return result.rows[0]
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserRepo, userid: `${userId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getAllUserRepo, userId: `${userId}`, operation: config.method.get})
    }
}

const getAllUserByParent = async (value, parentId) => {
    try {
        const data = value + "%";
        const result = await pool.query(dbQuery.getAllUserByParentQuery, [data, parentId]);
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserByParentRepo, userid: `${parentId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserByParentRepo, userid: `${parentId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getAllUserByParentRepo, userId: `${parentId}`, operation: config.method.get})
    }
}

const getAllUserByParentCustomer = async (value, parentId) => {
    try {
        const data = value + "%";
        const result = await pool.query(dbQuery.getAllUserByParentCustomerQuery, [data, parentId]);
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserByParentCustomerRepo, userid: `${parentId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserByParentCustomerRepo, userid: `${parentId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getAllUserByParentCustomerRepo, userId: `${parentId}`, operation: config.method.get})
    }
}


const getAllUserOperatorIdRepo = async (id) => {
    try {
        const result = await pool.query(dbQuery.getAllUserOperatorId, [id])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserOperatorIdRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.getAllUserOperatorIdRepo, userid: `${operatorId}`, operation: config.method.get, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.getAllUserOperatorIdRepo, userId: `${operatorId}`, operation: config.method.get})
    }
}

const operatorBalance = async (operatorId) => {
    try {
        const result = await pool.query(dbQuery.operatorIdDetailQuery, [operatorId])
        return result.rows
    } catch (error) {
        // logger.warns({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.operatorBalance, userid: `${operatorId}`, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.fail, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
        // logger.errors({ file_name: config.fileName.usermanagementRepo, method_name: config.methodName.operatorBalance, userid: `${operatorId}`, operation: config.method.put, subOperation: config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.usermanagementRepo, methodName: config.methodName.operatorBalance, userId: `${operatorId}`, operation: config.method.put})
    }
}


module.exports = { userStatusRepo, operatorSearchByIdRepo, operatorBalance, agentUpdate, resetPasswordRepo, getAllUserOperatorIdRepo, updateInActiveCredentialsRepo, updateActiveCredentialsRepo, getAllUserByParentCustomer, getAllUserByParent, agentAdd, getAllUser, getRole, changePasswordRepo, userSearchByIdRepo, addUserCredentialRepo, userGetByIdRepo, userGetAllRepo, userDeleteRepo }