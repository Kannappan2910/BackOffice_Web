const pool = require('../repo/db_connection');
const dbQuery = require('../repo/dbQuery')
const config = require('../config/app_config.json');
const logger = require('@platform_jewels/bassure-node/service/logger')
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const moment = require('moment')
const momenttz = require('moment-timezone')
const errorHandling = require('../service/errorhandling_service')

const historyRepo = async (body, ip, auditType, createdBy,userType) => {
    try {
        
        let result = await pool.query(dbQuery.addLoginHistory, [
            body.userId,
            moment().format('YYYY-MM-DD HH:mm:ss'),
             ip,
            auditType,
            createdBy,
            userType
        ])
        return result.rows
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryAddRepo, userid: `${body.userId}`, operation:config.method.post, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: config.errorMessage.unhandled });
        // logger.errors({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryAddRepo, userid: `${body.userId}`, operation:config.method.post, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.loginHistoryRepo, methodName: config.methodName.loginHistoryAddRepo, userId: `${body.userId}`, operation: config.method.post})
    }
}

const getAuditRepo = async (userId) => {
    try {
        let getLoginResult = await pool.query(dbQuery.getByIdLoginHistory, [userId])
        return getLoginResult.rows
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetByIdRepo, userid: `${userId}`, operation:config.method.get, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: config.errorMessage.unhandled });
        // logger.errors({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetByIdRepo, userid: `${userId}`, operation:config.method.get, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.loginHistoryRepo, methodName: config.methodName.loginHistoryGetByIdRepo, userId: `${userId}`, operation: config.method.get})
    }
}

const getAllAuditRepo = async (body,parentId) => {
    try { 
        const result = body.userId && body.auditType ? dbQuery.getAllLoginHistory + ` and user_id='${body.userId}' and audit_type='${body.auditType}' order by date desc` : body.userId ? dbQuery.getAllLoginHistory + ` and user_id='${body.userId}' order by date desc` : body.auditType ? dbQuery.getAllLoginHistory + ` and audit_type='${body.auditType}' order by date desc` : dbQuery.getAllLoginHistory + `order by date desc`
        const data = await pool.query(result, [
            parentId,
            body.fromdate,
            body.todate
        ])
        return data.rows
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllRepo, userid: `${body.userId}`, operation:config.method.post, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: config.errorMessage.unhandled });
        // logger.errors({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllRepo, userid: `${body.userId}`, operation:config.method.post, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.loginHistoryRepo, methodName: config.methodName.loginHistoryGetAllRepo, userId: `${body.userId}`, operation: config.method.post})
    }
}

const getAllAuditOperatorRepo = async (body,parentId) => {
    try { 
        const result = body.userId && body.auditType ? dbQuery.getAllLoginHistoryOperator + ` and user_id='${body.userId}' and audit_type='${body.auditType}' order by date desc` : body.userId ? dbQuery.getAllLoginHistoryOperator + ` and user_id='${body.userId}' order by date desc` : body.auditType ? dbQuery.getAllLoginHistoryOperator + ` and audit_type='${body.auditType}' order by date desc` : dbQuery.getAllLoginHistoryOperator + `order by date desc`
        const data = await pool.query(result, [
            parentId,
            body.fromdate,
            body.todate
        ])
        return data.rows
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllOperatorRepo, userid: `${body.userId}`, operation:config.method.post, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: config.errorMessage.unhandled });
        // logger.errors({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllOperatorRepo, userid: `${body.userId}`, operation:config.method.post, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.loginHistoryRepo, methodName: config.methodName.loginHistoryGetAllOperatorRepo, userId: `${body.userId}`, operation: config.method.post})
    }
}


const getAllAuditChildRepo = async (body) => {
    try { 
        const result = body.userId && body.auditType ? dbQuery.getAllLoginHistoryQuery + ` and user_id='${body.userId}' and audit_type='${body.auditType}' order by date desc` : body.userId ? dbQuery.getAllLoginHistoryQuery + ` and user_id='${body.userId}' order by date desc` : body.auditType ? dbQuery.getAllLoginHistoryQuery + ` and audit_type='${body.auditType}' order by date desc` : dbQuery.getAllLoginHistoryQuery +`order by date desc`
        const data = await pool.query(result, [
            body.parentId,
            body.fromdate,
            body.todate
        ])
        return data.rows
    }
    catch (error) {
        // logger.warns({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllChildRepo, userid: `${body.userId}`, operation:config.method.post, subOperation: config.subOperation.persists, result:config.result.success, label: ``, errorcode: config.errorMessage.unhandled });
        // logger.errors({ file_name: config.fileName.loginHistoryRepo, method_name: config.methodName.loginHistoryGetAllChildRepo, userid: `${body.userId}`, operation:config.method.post, subOperation:config.subOperation.exit, result:config.result.fail, label: `${error.message}`, errorcode: `` });
        // errorHandler.handleError(error)
        errorHandling.handleError({ error: error, fileName: config.fileName.loginHistoryRepo, methodName: config.methodName.loginHistoryGetAllChildRepo, userId: `${body.userId}`, operation: config.method.post})
    }
}

module.exports = { historyRepo, getAuditRepo, getAllAuditRepo,getAllAuditOperatorRepo,getAllAuditChildRepo }
















 //     if(body.userId){
        //         result = await Pool.query(dbQuery.getLoginHistoryById,[
        //           body.userId,  
        //           body.parentId,
        //           body.fromdate,
        //           body.todate
        //         ])  

        //     }
        //    else if(body.auditType){
        //       result=await Pool.query(dbQuery.getLoginHistoryByType,[
        //         body.auditType,
        //         body.parentId,
        //         body.fromdate,
        //         body.todate
        //       ])

        //     }
        //   else if(body.userId && body.auditType){
        //         result=await Pool.query(dbQuery.getHistoryByAll,[
        //             body.userId,
        //             body.parentId,
        //             body.fromdate,
        //             body.todate,
        //             body.auditType
        //         ])

        //     }
        //     else{
        //         result=await Pool.query(dbQuery.getAllLoginHistory,[
        //             body.parentId,
        //             body.fromdate,
        //             body.todate
        //         ])

        //     }
        // return result.rows
