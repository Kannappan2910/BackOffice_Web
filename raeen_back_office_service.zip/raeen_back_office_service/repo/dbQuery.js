const appConfig = require('../config/app_config.json')

const userAddQuery = `insert into ${appConfig.Table.UserManagement}(user_id,password,user_type,created_by,parent_id,operator_id,initial_login,user_status,login_status,notes,created_at)values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)returning *`
const betslipAddQuery = `insert into ${appConfig.Table.Betslip} (customer_id,stack1,stack2,stack3,stack4,plus1,plus2,plus3,plus4) values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning *`
const getOperatorBalanceQuery = `select balance from ${appConfig.Table.Operator} where operator_id=$1`
const addOperatorBalanceQuery = `update ${appConfig.Table.Operator} set balance = balance-$2 where operator_id=$1`
const updateOperatorBalanceQuery = `update ${appConfig.Table.Operator} set balance = balance-($2) where operator_id=$1`
const deleteUserQuery = `delete from ${appConfig.Table.UserManagement} where user_id=$1  RETURNING *`
const deleteBetSlipQuery = `delete from ${appConfig.Table.Betslip} where customer_id=$1`
const userGetByIdQuery = `select user_id,user_status,user_type,initial_login,notes from ${appConfig.Table.UserManagement} where user_id=$1`

const operatorSettle = `update ${appConfig.Table.Operator} set balance = balance + $1 where operator_id=$2 returning *`;
const operatorRiskBalance = `update ${appConfig.Table.Operator} set balance=balance+$2 where operator_id=$1 RETURNING *`;
const operatorAdminDelete = `delete from ${appConfig.Table.UserManagement} where operator_id=$1 returning *`
const operatorDelete = `delete from ${appConfig.Table.Operator} where operator_id=$1 returning *`;
const userGetAllActiveQuery = `select user_id,user_status,user_type,initial_login from ${appConfig.Table.UserManagement} where user_status=$1  AND created_by=$2 and user_type=$3`
const userGetAllInActiveQuery = `select user_id,user_status,user_type,initial_login from ${appConfig.Table.UserManagement} where user_status not in($1)  AND created_by=$2`
const userChangePasswordQuery = `update ${appConfig.Table.UserManagement} set password = $2 ,initial_login=$3where user_id = $1`
const userResetPasswordQuery = `update ${appConfig.Table.UserManagement} set password = $2 where user_id = $1`
const userUpdateActiveQuery = `update ${appConfig.Table.UserManagement} set user_status= $2,notes=$3,updated_by=$4,updated_at=$5 WHERE user_id=$1 returning *`
const userUpdateInActiveQuery = `with parent as (update ${appConfig.Table.UserManagement} set user_status= $2,notes=$3,updated_by=$4,updated_at=$5 WHERE user_id=$1 returning user_id,user_type), child as (update ${appConfig.Table.UserManagement} set user_status=$2,updated_by=$4,updated_at=$5 WHERE exists(select user_id from parent) and $1 = any(ARRAY[parent_id]) returning user_id,user_type) select user_id,user_type from child;`
const getRoleQuery = `select * from ${appConfig.Table.Role} where parent_name=$1`
const userSearchByIdQuery = `select user_id from ${appConfig.Table.UserManagement} where user_id ilike $1 AND (created_by=$2 or user_type=$2)`
const operatorSearchByIdQuery = `select user_id from ${appConfig.Table.UserManagement} where user_id ilike $1 AND created_by=$2 and user_type=$3`
const getAllUserQuery = `select * from ${appConfig.Table.UserManagement} where created_by=$1`
const getAllUserByParentQuery = `select user_id from ${appConfig.Table.UserManagement} where user_id ilike $1 AND $2 = any(array[parent_id])`
const getAllUserByParentCustomerQuery = `select user_id from ${appConfig.Table.UserManagement} where user_id ilike $1 AND $2 = any(array[parent_id]) and user_type='Customer' `
const getAllUserOperatorId = `select user_id,user_type,operator_id,user_status from ${appConfig.Table.UserManagement} where operator_id=$1`
const getOperatorCountQuery = `select * from ${appConfig.Table.Operator}`

const operatorAdd = `insert into ${appConfig.Table.Operator} (operator_name,contact_number,operator_status,address_line_1,address_line_2,city,country_code,post_code,created_by,betfairappkey,betfairusername,betfairpassword,admin_name,balance) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) returning *`
const insertOperatorQuery = `insert into ${appConfig.Table.UserManagement}(user_id,password,user_type,created_by,created_at,parent_id,operator_id,initial_login,user_status,login_status,notes)values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)returning *`
const deleteOperatorQuery = `delete from ${appConfig.Table.Operator} where operator_id=$1 returning *`
const deleteOperatorAdminQuery = `delete from ${appConfig.Table.UserManagement} where operator_id=$1`
const operatorGetByIdQuery = `select o.operator_name,o.operator_id,o.admin_name,o.contact_number,o.address_line_1,o.address_line_2,o.city,o.country_code,o.post_code,um.user_id,o.betfairappkey,o.betfairusername,o.betfairpassword,o.balance,um.user_status from ${appConfig.Table.UserManagement} um join operator o on o.operator_id = um.operator_id where um.user_id= $1 `
const operatorUpdateQuery = `update  ${appConfig.Table.Operator}  set operator_name=$2,contact_number=$3,operator_status=$4,address_line_1=$5,address_line_2=$6,city=$7,post_code=$8 where operator_id=$1 returning *`
const operatorUpdateActiveQuery = `update ${appConfig.Table.UserManagement} set user_status=$1 where user_id=$2 returning *`
const operatorUpdateInActiveQuery = `update ${appConfig.Table.UserManagement} set user_status=$1 where operator_id=$2 returning *`
const operatorIdDetailQuery = `select operator_id,betfairusername,betfairpassword,betfairappkey,id ,balance from ${appConfig.Table.Operator} where operator_id=$1`
const operatorIdListQuery = `select operator_id,betfairusername,betfairpassword,betfairappkey from  ${appConfig.Table.Operator} `
const operatorUpdateBalance = `update ${appConfig.Table.Operator} set id=$2,balance=$3 where operator_id=$1`
const operatorAdminGetAll = `select o.operator_id,o.operator_name,o.admin_name,o.contact_number,um.user_id,o.betfairappkey,o.betfairusername,o.betfairpassword,o.balance from ${appConfig.Table.UserManagement} um join ${appConfig.Table.Operator} o on o.operator_id = um.operator_id where um.user_status=$1 and um.user_type=$2`
const loginUserQuery = `select * from ${appConfig.Table.UserManagement} where user_id=$1`
const updateStatusLoginQuery = `update ${appConfig.Table.UserManagement} set login_status='LOGIN',last_login=$2 where user_id=$1 returning login_status`
const logoutQuery = `update ${appConfig.Table.UserManagement} set login_status='LOGOUT' where user_id=$1`


//multiple ip

const multipleipuserIdfromtoparent = `select ip,count(distinct(user_id)),STRING_AGG(distinct(user_id),',' order by user_id) As Players from ${appConfig.Table.LoginHistory} where ip in(select ip from ${appConfig.Table.LoginHistory} where ip ilike $1 and user_id ilike $2) and audit_type='Login' and  date between $3 and $4 and user_type='Customer' group by ip;`
const multipleipparentfromto = `select ip,count(distinct(user_id)),STRING_AGG(distinct(user_id), ',' ORDER BY user_id) AS players from ${appConfig.Table.LoginHistory} where audit_type='Login' and ip ilike $1 and date between $2 and $3 and user_type='Customer'  group by ip;`
const multipleuseridfromto = `select ip,count(distinct(user_id)), STRING_AGG(distinct(user_id),',' order by user_id) AS Players from ${appConfig.Table.LoginHistory} where ip in(select ip from ${appConfig.Table.LoginHistory} where user_id ilike $1) and audit_type='Login' and date between $2 and $3 and user_type='Customer'  group by ip;`
const multipleip = `select ip,count(distinct(user_id)),STRING_AGG(distinct(user_id), ',' ORDER BY user_id) AS players from ${appConfig.Table.LoginHistory} where audit_type='Login' and date between $1 and $2 and user_type='Customer' group by ip;`

//login history
const addLoginHistory = `insert into ${appConfig.Table.LoginHistory} (user_id,date,ip,audit_type,parent_id,user_type) values($1,$2,$3,$4,$5,$6) RETURNING *`
const getByIdLoginHistory = `select * from ${appConfig.Table.LoginHistory} where user_id=$1 order by date desc`
const getAllLoginHistory = `select * from ${appConfig.Table.LoginHistory} where parent_id=$1 and date between $2 and $3`
const getAllLoginHistoryQuery = `select * from ${appConfig.Table.LoginHistory} where user_id=$1 and date between $2 and $3`
const getAllLoginHistoryOperator = `select * from ${appConfig.Table.LoginHistory} where parent_id=$1 and date between $2 and $3 and user_type not in('OperatorAdmin')`


//block ip
const addIpAddress = `INSERT INTO  ${appConfig.Table.IpAddress} (ip_address,blocked_date,ip_status,comments,parentid,deviceid,operator_id) values($1,$2,$3,$4,$5,$6,$7) returning ip_address`;
const blockedIpAddressGetByParentId = `select * from ${appConfig.Table.IpAddress} where ip_status=$1 and parentid=$2 and operator_id=$3`
const searchIpAddress = `select * from ${appConfig.Table.IpAddress} where ip_status='Block' and ip_address ilike $1 and parentid=$2 and operator_id=$3`;
const unblockByIpAddress = `delete from ${appConfig.Table.IpAddress} where ip_address=$1 returning *`;
const getAllIpAddress = `select ip_address from ${appConfig.Table.IpAddress} where operator_id=$1`;
const blockByIpAddres = `update ${appConfig.Table.IpAddress} set ip_status=$1,comments=$2 ,blocked_date=$5 where ip_address=$3 and deviceid=$4 returning *`
const updateInActiveCredentials = `with parent as (update ${appConfig.Table.UserManagement} set user_status= $2,notes=$3,updated_by=$4,updated_at=$5 WHERE user_id=$1 returning user_id,user_type), child as (update ${appConfig.Table.UserManagement} set user_status=$2,updated_by=$4,updated_at=$5 WHERE exists(select user_id from parent) and $1 = any(ARRAY[parent_id]) returning user_id,user_type,operator_id) select user_id,user_type,operator_id from child;`

//betslip
const betslipGetById = `select * from ${appConfig.Table.Betslip} where ${appConfig.columnName.customerId}=$1`;
const customerBetSlipAdd = `insert into ${appConfig.Table.Betslip}(${appConfig.columnName.customerId},${appConfig.columnName.stack1},${appConfig.columnName.stack2},${appConfig.columnName.stack3},${appConfig.columnName.stack4},${appConfig.columnName.plus1},${appConfig.columnName.plus2},${appConfig.columnName.plus3},${appConfig.columnName.plus4}) values($1,$2,$3,$4,$5,$6,$7,$8,$9) `;
const updateBetSlip = `update ${appConfig.Table.Betslip} set ${appConfig.columnName.stack1}=$2, ${appConfig.columnName.stack2}=$3, ${appConfig.columnName.stack3}=$4, ${appConfig.columnName.stack4}=$5,${appConfig.columnName.plus1}=$6,${appConfig.columnName.plus2}=$7,${appConfig.columnName.plus3}=$8,${appConfig.columnName.plus4}=$9 where ${appConfig.columnName.customerId} = $1 RETURNING *`;


//footer
const checkContentExist = `select * from ${appConfig.Table.Content} where content_name=$1`
const insertTransaction = `insert into ${appConfig.Table.Content}(content_name,content_detail) values($1,$2) RETURNING *`
const updateContent = `update ${appConfig.Table.Content} set content_detail=$2 where content_name=$1 RETURNING *`
const getContent = `select * from ${appConfig.Table.Content} where content_name=$1`
const getCustomerContent = `select * from ${appConfig.Table.ApkDetails}`
const updateCustomerContent = `update ${appConfig.Table.ApkDetails} set apk_link=$1,last_updated=$2 RETURNING * `
const deleteContent = `delete from ${appConfig.Table.Content} where content_name=$1`

//dashboard
const getRolehierarchy = `WITH RECURSIVE rolehierarchy AS (SELECT * FROM ${appConfig.Table.Role} WHERE parent_name=$1 UNION ALL select r.* from ${appConfig.Table.Role} r join rolehierarchy on rolehierarchy .role_name=r.parent_name) select role_name from rolehierarchy;`

const dashboradUsers = `select user_type, count(user_id) from ${appConfig.Table.UserManagement} where $1 = ANY(ARRAY[parent_id]) group by user_type`
const dashboardOperator = `select user_type, count(user_id) from ${appConfig.Table.UserManagement} where operator_id=$1 and user_type not in('OperatorAdmin') group by user_type`


// competition 
const competitionList = `select competition_id_list from ${appConfig.Table.Competition} where operator_id = $1 and event_type_id=$2`
const uncheckCompetition = `update ${appConfig.Table.Competition} set competition_id_list = $2 where operator_id = $1 and event_type_id=$3 RETURNING *`
const opertorCompetitionData = `insert into  ${appConfig.Table.Competition} (operator_id,event_type_id,competition_id_list) values ($1,$2,'{}')`

//permission
const permission = `select * from ${appConfig.Table.Permission}`
const operation = `select * from ${appConfig.Table.Operation}`



module.exports = {
    getRolehierarchy,dashboradUsers,dashboardOperator,permission,operation,
    betslipGetById, customerBetSlipAdd, updateBetSlip, checkContentExist, insertTransaction, updateContent, getContent, getCustomerContent, updateCustomerContent, deleteContent,
    operatorDelete, operatorAdminDelete, operatorRiskBalance, operatorSettle,
    addIpAddress, blockedIpAddressGetByParentId, searchIpAddress, unblockByIpAddress, getAllIpAddress, blockByIpAddres, opertorCompetitionData,
    uncheckCompetition, competitionList, userAddQuery, betslipAddQuery, getOperatorBalanceQuery, updateOperatorBalanceQuery, deleteUserQuery, deleteBetSlipQuery,
    userGetByIdQuery, userGetAllActiveQuery, userGetAllInActiveQuery, userChangePasswordQuery, userUpdateActiveQuery,
    userUpdateInActiveQuery, getRoleQuery, userSearchByIdQuery, getAllUserQuery, getAllUserByParentQuery, getAllUserByParentCustomerQuery,
    getOperatorCountQuery, insertOperatorQuery, deleteOperatorQuery, deleteOperatorAdminQuery,
    operatorGetByIdQuery, operatorUpdateQuery, operatorUpdateActiveQuery, operatorUpdateInActiveQuery, operatorIdDetailQuery,
    operatorIdListQuery, operatorUpdateBalance, operatorAdd, loginUserQuery, updateStatusLoginQuery, logoutQuery,
    multipleipuserIdfromtoparent, multipleipparentfromto, multipleuseridfromto, multipleip, operatorAdminGetAll,
    addLoginHistory, getByIdLoginHistory, getAllLoginHistory, getAllUserOperatorId, getAllLoginHistoryQuery, getAllLoginHistoryOperator,
    userResetPasswordQuery, addOperatorBalanceQuery, operatorSearchByIdQuery, updateInActiveCredentials

}
