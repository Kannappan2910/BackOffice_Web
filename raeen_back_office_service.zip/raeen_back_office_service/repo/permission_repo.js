const pool = require('./db_connection');
const dbQuery = require('./dbQuery');
const errorHandling = require('../service/errorhandling_service')
const config = require('../config/app_config.json')

const permission = async () => {
  try {
    const result = await pool.query(dbQuery.permission, [])
    return result.rows
  } catch (error) {
    errorHandling.handleError({ error: error, fileName: config.fileName.permissionRepo, methodName: config.methodName.permission, userId: ``, operation: ''})
  }
}

const operation = async () => {
  try {
    const result = await pool.query(dbQuery.operation, [])
    return result.rows
  } catch (error) {
    errorHandling.handleError({ error: error, fileName: config.fileName.permissionRepo, methodName: config.methodName.operation, userId: ``, operation: ''})

  }
}


module.exports = { permission, operation }