const dbConfig = require('../config/app_config.json');
const { Pool } = require("pg");
const logger = require('@platform_jewels/bassure-node/service/logger')

const pool = new Pool({
  user: process.env.DB_POSTGRES_USER ? process.env.DB_POSTGRES_USER : dbConfig.db_postgres.user,
  host: process.env.DB_POSTGRES_HOST ? process.env.DB_POSTGRES_HOST : dbConfig.db_postgres.host,
  database: process.env.DB_POSTGRES_DATABASE ? process.env.DB_POSTGRES_DATABASE : dbConfig.db_postgres.database,
  password: process.env.DB_POSTGRES_PASSWORD ? process.env.DB_POSTGRES_PASSWORD : dbConfig.db_postgres.password,
  port: process.env.DB_POSTGRES_PORT ? process.env.DB_POSTGRES_PORT : dbConfig.db_postgres.port,
});

pool.on("error", (err, client) => {
  logger.errors({ file_name: 'DbConnection', method_name: 'Pool', userid: ``, operation: `create`, subOperation: `Exit`, result: `Fail`, label: `${err}`, errorcode: `${602}` })
})

module.exports = pool;