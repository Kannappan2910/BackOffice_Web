const Redis = require('ioredis')
const appConfig = require('../config/app_config.json');

const redis = new Redis({
  host: process.env.REDIS_HOST ? process.env.REDIS_HOST : appConfig.redis.host,
  port: process.env.REDIS_PORT ? process.env.REDIS_PORT : appConfig.redis.port,
  password: process.env.REDIS_PASSWORD ? process.env.REDIS_PASSWORD : appConfig.redis.password,
  db: process.env.REDIS_DB ? process.env.REDIS_DB : appConfig.redis.db
});

const sub = new Redis({
  host: process.env.REDIS_HOST ? process.env.REDIS_HOST : appConfig.redis.host,
  port: process.env.REDIS_PORT ? process.env.REDIS_PORT : appConfig.redis.port,
  password: process.env.REDIS_PASSWORD ? process.env.REDIS_PASSWORD : appConfig.redis.password,
  db: process.env.REDIS_DB ? process.env.REDIS_DB : appConfig.redis.db
});

const pub = new Redis({
  host: process.env.REDIS_HOST ? process.env.REDIS_HOST : appConfig.redis.host,
  port: process.env.REDIS_PORT ? process.env.REDIS_PORT : appConfig.redis.port,
  password: process.env.REDIS_PASSWORD ? process.env.REDIS_PASSWORD : appConfig.redis.password,
  db: process.env.REDIS_DB ? process.env.REDIS_DB : appConfig.redis.db
});

module.exports = { pub, redis, sub };