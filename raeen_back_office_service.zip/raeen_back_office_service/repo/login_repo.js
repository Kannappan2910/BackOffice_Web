const pool = require('../repo/db_connection');
const dbQuery = require('../repo/dbQuery')
const logger = require('@platform_jewels/bassure-node/service/logger')
const errorHandler = require('@platform_jewels/bassure-node/service/errorHandler')
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const moment = require('moment')
const app_config = require('../config/app_config.json')
const errorHandling = require('../service/errorhandling_service')


const loginUserRepo = async (userId) => {
  try {
    const result = await pool.query(dbQuery.loginUserQuery, [userId]) 
    return result
  } catch (error) {
    // logger.warns({ file_name:  app_config.fileName.loginUserRepo, method_name: app_config.methodName.loginUserRepo, userid: `${userId}`, operation:app_config.method.post, subOperation: app_config.subOperation.persists, result: app_config.result.fail, label: ``, errorcode: config.response_code.duplication });
    // logger.errors({ file_name:  app_config.fileName.loginUserRepo, method_name: app_config.methodName.loginUserRepo, userid: `${userId}`, operation:app_config.method.post, subOperation: app_config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: app_config.fileName.loginUserRepo, methodName: app_config.methodName.loginUserRepo, userId: `${userId}`, operation: app_config.method.post})
  }
}


const updateUserLoginStatusRepo = async (body) => {
  try {
    const result =await pool.query(dbQuery.updateStatusLoginQuery, [body.userId, moment().format('YYYY-MM-DD HH:mm:ss')])
    return result
  } catch (error) {
    // logger.warns({ file_name:  app_config.fileName.loginUserRepo, method_name:app_config.methodName.updateUserLoginStatusRepo, userid: `${body.userId}`, operation: app_config.method.put, subOperation: app_config.subOperation.persists, result: app_config.result.fail, label: ``, errorcode: config.response_code.duplication });
    // logger.errors({ file_name:  app_config.fileName.loginUserRepo, method_name: app_config.methodName.updateUserLoginStatusRepo, userid: `${body.userId}`, operation: app_config.method.put, subOperation: app_config.subOperation.exit, result: ``, label: `${error.message}`, errorcode: `` });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: app_config.fileName.loginUserRepo, methodName: app_config.methodName.updateUserLoginStatusRepo, userId: `${body.userId}`, operation: app_config.method.put})
  }

}


const logoutUserRepo = async (body) => {
  try {
    const result = await pool.query(dbQuery.logoutQuery, [body.userId])
    return result
  }
  catch (error) {
    // logger.warns({ file_name:  app_config.fileName.loginUserRepo, method_name: app_config.methodName.logoutUserRepo, userid: `${body.userId}`, operation: app_config.method.put, subOperation: app_config.subOperation.persists, result: app_config.result.fail, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
    // logger.errors({ file_name:  app_config.fileName.loginUserRepo, method_name: app_config.methodName.logoutUserRepo, userid: `${body.userId}`, operation: app_config.method.put, subOperation: app_config.subOperation.exit, result: app_config.result.fail, label: `${error.message}`, errorcode: config.response_code.error_dbissue_serverissue });
    // errorHandler.handleError(error)
    errorHandling.handleError({ error: error, fileName: app_config.fileName.loginUserRepo, methodName: app_config.methodName.logoutUserRepo, userId: `${body.userId}`, operation: app_config.method.put})
  }
}


module.exports = { loginUserRepo, updateUserLoginStatusRepo, logoutUserRepo }