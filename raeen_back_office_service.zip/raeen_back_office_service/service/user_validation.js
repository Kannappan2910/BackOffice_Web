const { check: body, check } = require("express-validator");
const logger = require('@platform_jewels/bassure-node/service/logger')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json')
const { userId, passwords, ipAddress1, ipAddress2 } = require('../config/regex')
const { validation_error, subOperation, result, fileName, methodName, validate, method } = require('../config/app_config.json')

function userValidation() {
    return [
        body(validate.userId).custom((val, data) => {
            const token = data.req.token
            if (!(userId.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.userId, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.userId);
            }
            return true;
        }),
        body(validate.password).custom((val, data) => {
            const userId = data.req.body.userId
            if (!(passwords.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            if (val.includes(userId)) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passwordMessage, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.passwordMessage)
            }
            return true
        }),
        body(validate.adminPassword).custom((val) => {
            if (!(passwords.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.adminPassword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            return true
        })

    ]
}

function userUpdateValidation() {
    return [
        body(validate.userId).custom((val, data) => {
            const token = data.req.token
            if (!(userId.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userUpdateValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.userId, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.userId);
            }
            return true;
        }),
        body(validate.adminPassword).custom((val) => {

            if (!(passwords.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.userUpdateValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            return true
        })

    ]

}

function changePassword() {
    return [
        body(validate.userId).custom((val, val1) => {
           
            let password = val1.req.body
            let userId = val1.req.body.userId
            if (password.newPassword == password.oldPassword) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.changePassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.samePasssword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.samePasssword);
            }
            if (!(passwords.test(password.oldPassword)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.changePassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            if (!(passwords.test(password.newPassword)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.changePassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            if (password.newPassword.includes(userId)) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.changePassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passwordMessage, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.passwordMessage)
            }
            return true;
        }),
    ]
}

function resetPassword() {
    return [
        body(validate.newPassword).custom((val, data) => {
            let password = data.req.body.newPassword
            let userId = data.req.body.userId
            if (!(passwords.test(password)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.resetPassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            if (val.includes(userId)) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.resetPassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passwordMessage, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.passwordMessage)
            }
            return true;
        }),
    ]
}

function verifyPassword() {
    return [
        body(validate.adminPassword).custom((val, data) => {
            let password = data.req.token.adminPassword
            if (!(passwords.test(password)) || val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.resetPassword, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            return true;
        }),
    ]
}
function addIpAddressValidation() {
    return [
        body(validate.ip).optional().custom((val) => {
            if (val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.addIpAddressValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.ipAddress, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.ipAddress)
            }
            return true
        }),
        // check(validate.ip).optional().custom((val) => {
        //     if (!(ipAddress2.test(val)) || val == undefined) {
        //         logger.warns({ file_name: fileName.userValidation, method_name: methodName.addIpAddressValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.ipAddress, errorcode: response_code.field_validation });
        //         throw new Error(validation_error.ipAddress)
        //     }
        //     return true
        // }),

    ]
}
function validation() {
    return [
        body(validate.userId).custom((val) => {

            if (!(userId.test(val)) && val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.validation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.userId, errorcode: response_code.field_validation });
                throw new Error(validation_error.userId);
            }
            return true;
        }),
        body(validate.password).custom((val) => {
            if (!(passwords.test(val)) && val == undefined) {
                logger.warns({ file_name: fileName.userValidation, method_name: methodName.validation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.passsword, errorcode: appConfig.response_code.field_validation });
                throw new Error(validation_error.password);
            }
            return true;
        }),
    ]
}
// function multipleIpValidation() {
//     return [
//         check(validate.userId).custom((val) => {
//             if (!(userId.test(val)) || val == undefined) {
//                 logger.warns({ file_name: fileName.userValidation, method_name: methodName.multipleIpValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.userId, errorcode: response_code.field_validation });
//                 throw new Error(appConfig.validation_error.userId)
//             }
//             return true
//         }),
//         check(validate.ip).optional().custom((val) => {
//             if (!(ipAddress1.test(val)) || val == undefined) {
//                 logger.warns({ file_name: fileName.userValidation, method_name: methodName.multipleIpValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.ipAddress, errorcode: response_code.field_validation });
//                 throw new Error(validation_error.ipAddress)
//             }
//             return true
//         }),
//         check(validate.ip).optional().custom((val) => {
//             if (!(ipAddress2.test(val)) || val == undefined) {
//                 logger.warns({ file_name: fileName.userValidation, method_name: methodName.multipleIpValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.ipAddress, errorcode: response_code.field_validation });
//                 throw new Error(validation_error.ipAddress)
//             }
//             return true
//         }),
//         check(validate.fromDate).custom((val) => {
//             if (val == undefined) {
//                 logger.warns({ file_name: fileName.userValidation, method_name: methodName.multipleIpValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.fromDate, errorcode: response_code.field_validation });
//                 throw new Error(validation_error.fromDate)
//             }
//             return true
//         }),
//         check(validate.toDate).custom((val) => {
//             if (val == undefined) {
//                 logger.warns({ file_name: fileName.userValidation, method_name: methodName.multipleIpValidation, userId: `${val}`, operation: method.put, subOperation: subOperation.validation, result: result.fail, label: validation_error.toDate, errorcode: response_code.field_validation });
//                 throw new Error(validation_error.toDate)
//             }
//             return true
//         })
//     ]
// }

module.exports = { verifyPassword, userValidation, changePassword, resetPassword, userUpdateValidation, addIpAddressValidation, validation }