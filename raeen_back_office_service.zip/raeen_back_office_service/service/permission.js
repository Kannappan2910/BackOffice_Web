const loginrepo = require('../repo/permission_repo')
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const { redis } = require('../repo/redis_connection')
const appConfig = require('../config/app_config.json')
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const jwt = require('jsonwebtoken')


async function permission(req, res) {
    const permissionList = await loginrepo.permission()
    let operationList = await loginrepo.operation()
    let t = permissionList && permissionList.map(e => {
        const list = e.permissionlist
        let finalList = []
        list.map(permission => {
            operationList && operationList.map(operation => {
                redis.set(operation.endpoint, operation.operation_name)
                if (operation.p_id == permission) {
                    finalList.push(operation.operation_name)
                }
            })
        })

        redis.set(e.rolename, JSON.stringify(finalList))
        return finalList
    })

}


function getPermission(req, res) {
    cr_handle.handleCommonResponse({successCb:(async (successCb) => {
        return successCb({
            data: cr.responseCb(
                cr.headerCb({ code: config.response_code.success })
                , cr.bodyCb({ val: req.token }))
        })
    }), res:res,errorMessage:appConfig.errorMessage});
}

module.exports = { permission, getPermission }

