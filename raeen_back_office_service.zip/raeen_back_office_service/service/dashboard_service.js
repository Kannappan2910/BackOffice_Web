
const { response_messages, errorMessage, fileName, methodName } = require('../config/app_config.json')
const dashboardRepo = require('../repo/dashboard_repo')
let cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
let cr = require('@platform_jewels/bassure-node/entity/common_respone');
const { successResponse } = require('./common_service')
const appConfig = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger')

//dashboard get
function dashboardDataGetService(req, res,) {
    return cr_handle.handleCommonResponse({successCb:(async (successCb) => {
        let result;
        let finalResult = [];
        if (req.token.userType == appConfig.userType.operatorAdmin) {
            result = await dashboardRepo.dashboardOperatorDataGetRepo(req.token.operatorId);
        } else {
            result = await dashboardRepo.dashboardDataGetRepo(req.token.userId);
        }
        let totalUser = 0;
        const hierarchy = await dashboardRepo.getRolehierarchy(req.token.userType)
        hierarchy.map(e => {
            if (result.length > 0) {
                result.map(f => {
                    if (e.role_name == f.user_type) {
                        finalResult.push({
                            userType: appConfig.usertype[e.role_name],
                            count: f.count
                        })
                        totalUser = parseInt(f.count) + totalUser
                    }
                    // else {
                    //     finalResult.push({
                    //         userType: appConfig.usertype[e.role_name],
                    //         count: 0
                    //     })
                    // }
                })
            } else {

                finalResult.push({
                    userType: appConfig.usertype[e.role_name],
                    count: 0
                })
                totalUser = 0
            }
        })
        finalResult.push({
            userType: "Total Users",
            count: totalUser
        })
        logger.infos({ file_name: appConfig.fileName.dashboardDataGetService, method_name: appConfig.methodName.dashboardDataGetService, userid: `${req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label:finalResult.length>0? appConfig.loggerMessage.data:appConfig.loggerMessage.noDataFound, errorcode: `` });
        successResponse({
            successCb: successCb,
            data: finalResult
        })
    }),res:res, errorMessage:appConfig.errorMessage,fileName:appConfig.fileName.dashboardDataGetService,methodName:appConfig.methodName.dashboardDataGetService,userId:`${req.params.id}`,operation:appConfig.method.get});
}














module.exports = {
    dashboardDataGetService
}















