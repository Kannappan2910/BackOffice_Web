const { handleCommonResponse } = require('@platform_jewels/bassure-node/service/response_handle_service');
const { redis } = require('../repo/redis_connection');
const { userStatusRepo } = require('../repo/usermanagement_repo');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json')
const appConfig = require('../config/app_config.json')

async function userStatus(userDetail, req) {
    let userStatuskey = userDetail.userType + "_" + userDetail.userId + "_" + userDetail.operatorId;
    let status = await redis.get(userStatuskey)
    if (status) {
        return userDetail.userType == appConfig.userType.platformAdmin ? appConfig.userstatus.active : !!(status == appConfig.userstatus.active || status == appConfig.userstatus.betlocked);
    } else {
        const data = await userStatusRepo(userDetail.userId)
        if (data) {
            redis.set(data.user_type + "_" + data.user_id + "_" + data.operator_id, data.user_status)
            return data.user_type == appConfig.userType.platformAdmin ? appConfig.userstatus.active : !!(data.user_status == appConfig.userstatus.active || data.user_status == appConfig.userstatus.betlocked);
        } else {
            return false
        }
    }
}


function createUserStatus(role, userId, operatorId, status) {
    let redisKey = role + "_" + userId + "_" + operatorId
    redis.set(redisKey, status)
}

module.exports = { userStatus, createUserStatus }