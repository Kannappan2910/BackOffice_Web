const loginRepo = require('../repo/login_repo')
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const logger = require('@platform_jewels/bassure-node/service/logger')
const appConfig = require('../config/app_config.json')
const { createToken } = require('@platform_jewels/bassure-node/service/token')
const respTime = require('@platform_jewels/bassure-node/service/responseTime')
const { body, validationResult } = require('express-validator');
const { successResponse } = require('./common_service')
const { User } = require('../entity/user');
const { getRole } = require('../repo/usermanagement_repo');
const { addLoginDetails } = require('./login_history_service');
const { compare, compareSync } = require('bcrypt');
const { redis } = require('../repo/redis_connection');

function userLoginService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: ``, errorcode: config.response_code.field_validation });
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        return cr_handle.handleCommonResponse({successCb:( async (successCb) => {
            const userId = req.body.userId
            const password = req.body.password
            req.body.userId = userId.trim()
            req.body.password = password.trim()
            let credentials = await loginRepo.loginUserRepo(req.body.userId)
            if (credentials.rows && credentials.rowCount > 0) {
                const status = await redis.get(`${credentials.rows[0].operator_id}` + "_BlockedIp") || []
                const ip = req.header('x-real-ip');
                if (!status.includes(ip) || credentials.rows[0].user_type == appConfig.userType.platformAdmin) {
                    if (req.body.loginType === appConfig.types.customer && credentials.rows[0].user_type !== appConfig.userType.customer) {
                        //negative response 
                        logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.method.post, result: ``, label: `${appConfig.response_messages.noDataFound}`, errorcode: config.response_code.no_data_found });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.no_data_found }),
                                cr.bodyCb({ val: appConfig.loginmessages.mismatch })
                            )
                        });
                    }
                    if (req.body.loginType === appConfig.types.bo && credentials.rows[0].user_type === appConfig.userType.customer) {
                        //negative response
                        logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.response_messages.noDataFound}`, errorcode: config.response_code.no_data_found });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.no_data_found }),
                                cr.bodyCb({ val: appConfig.loginmessages.mismatch })
                            )
                        });
                    }
                    // if (credentials.rows[0].login_status == appConfig.loginstatus.login) {
                    //     logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: 'POST', subOperation: 'exit', result: ``, label: `${appConfig.loginmessages.loginerror}`, errorcode: config.response_code.no_data_found });
                    //     return successCb({
                    //         data: cr.responseCb(
                    //             cr.headerCb({ code: config.response_code.no_data_found }),
                    //             cr.bodyCb({ val: appConfig.loginmessages.loginerror })
                    //         )
                    //     });
                    // } else {
                    if (credentials.rows[0].user_status == appConfig.userstatus.active || credentials.rows[0].user_status == appConfig.userstatus.betlocked) {
                        let isExists = await compare(req.body.password, credentials.rows[0].password)
                        if (!isExists) {
                            logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.loginmessages.mismatch}`, errorcode: config.response_code.no_data_found });
                            return successCb({
                                data: cr.responseCb(
                                    cr.headerCb({ code: config.response_code.no_data_found }),
                                    cr.bodyCb({ val: appConfig.loginmessages.mismatch })
                                )
                            });
                        }
                        let role = credentials.rows[0].user_type == appConfig.userType.customer ? null : await getRole(credentials.rows[0].user_type)
                        let userDetailTokenObj = { userId: credentials.rows[0].user_id, userType: credentials.rows[0].user_type, userTypeLabel: appConfig.usertype[credentials.rows[0].user_type], childRoleLabel: appConfig.usertype[role], createdBy: credentials.rows[0].created_by, parentId: credentials.rows[0].parent_id, operatorId: credentials.rows[0].operator_id, childRole: role }
                        let tokenDetails = createToken(userDetailTokenObj, appConfig.tokenValidity.access, appConfig.tokenValidity.refresh)
                        let updateCredentials = await loginRepo.updateUserLoginStatusRepo(req.body)
                        if (updateCredentials.rows.length > 0) {
                            const result = { ...credentials.rows[0], "token": tokenDetails }
                            addLoginDetails(req, appConfig.auditTypes.Login, credentials.rows[0].created_by, credentials.rows[0].user_type)
                            let userDetails = new User({})
                            userDetails.userId = result.user_id
                            userDetails.userType = result.user_type
                            userDetails.loginStatus = updateCredentials.rows[0].login_status
                            userDetails.userStatus = result.user_status
                            userDetails.initialLogin = result.initial_login
                            userDetails.childRole = role
                            userDetails.token = result.token
                           
                            logger.infos({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.response_messages.loggedInSucessfully, errorcode: `${config.response_code.success}` });
                         
                            return successCb({
                                data: cr.responseCb(
                                    cr.headerCb({ code: config.response_code.success }),
                                    cr.bodyCb({ val: userDetails })
                                ),
                            });
                        }
                        else {
                            logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.errorMessage.unhandled}`, errorcode: config.response_code.error_dbissue_serverissue });
                            return successCb({
                                data: cr.responseCb(
                                    cr.headerCb({ code: config.response_code.error_dbissue_serverissue }),
                                    cr.bodyCb({ val: appConfig.errorMessage.unhandled })
                                )
                            });
                        }
                    } else {
                        logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.response_messages.notFound}`, errorcode: config.response_code.not_found });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.not_found }),
                                cr.bodyCb({ val: appConfig.response_messages.notFound })
                            )
                        });
                    }
                    // }
                } else {
                    logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.response_messages.unauthorize}`, errorcode: config.response_code.unauthorize });
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: config.response_code.unauthorize }),
                            cr.bodyCb({ val: appConfig.response_messages.unauthorize })
                        )
                    });
                }
            } else {
                logger.errors({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLoginService, userid: `${req.body.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: ``, label: `${appConfig.loginmessages.mismatch}`, errorcode: config.response_code.no_data_found });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.no_data_found }),
                        cr.bodyCb({ val: appConfig.loginmessages.mismatch })
                    )
                });
            }
        }), res:res, errorMessage:appConfig.errorMessage,fileName:appConfig.fileName.loginService,methodName:appConfig.methodName.userLoginService,userId:`${req.body.userId}`,operation:appConfig.method.post});
    }
}


function userLogoutService(req, res) {
    return cr_handle.handleCommonResponse({successCb:(async (successCb) => {
        req.body.userId = req.token.userId
        await loginRepo.logoutUserRepo(req.body)
        addLoginDetails(req, appConfig.auditTypes.Logout, req.token.createdBy, req.token.userType)
        logger.infos({ file_name: appConfig.fileName.loginService, method_name: appConfig.methodName.userLogOutService, userid: `${req.body.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
        successResponse({
            successCb: successCb,
            data: appConfig.response_messages.logout
        })
    }),res:res, errorMessage:appConfig.errorMessage,fileName:appConfig.fileName.loginService,methodName:appConfig.methodName.userLogOutService,userId:`${req.body.userId}`,operation:appConfig.method.put});
}



module.exports = { userLoginService, userLogoutService }

