const { validationResult } = require("express-validator");
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const transactionRepo = require('../repo/contentRepo')
const respTime = require('@platform_jewels/bassure-node/service/processTime');
const { Apk } = require("../entity/apkdetails");
const { successResponse } = require("./common_service");
const appConfig = require('../config/app_config.json')

async function checkContentExistService(body) {
    return respTime.processTimeLogging(async () => {
        return await transactionRepo.checkContentExistRepo(body)
    }, "checkContentExistService")
}

async function addContentService(req, res) {
    const error = validationResult(req);
    return !error.isEmpty()
        ? cr_handle.fieldValidationResponse(res, error)
        : cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const response = await checkContentExistService(req.body)
                if (response.length > 0) {
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: config.response_code.duplication })
                        ),
                    })
                } else {
                    const result = await transactionRepo.addContentRepo(req.body)
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: !result ? config.response_code.error_dbissue_serverissue : config.response_code.success })
                            , cr.bodyCb({ val: result })
                        ),
                    });
                }
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.contentService, methodName: appConfig.methodName.addContentService, userId: ``, operation: appConfig.method.post
        });
}


async function updateContentService(req, res) {
    const error = validationResult(req);
    return !error.isEmpty()
        ? cr_handle.fieldValidationResponse(res, error)
        : cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const response = await checkContentExistService(req.body)
                if (response.length > 0) {
                    const result = await transactionRepo.updateContentRepo(req.body)
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: !result ? config.response_code.error_dbissue_serverissue : config.response_code.success })
                            , cr.bodyCb({ val: result })
                        ),
                    });
                } else {
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: config.response_code.not_found })
                        ),
                    })
                }
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.contentService, methodName: appConfig.methodName.updateContentService, userId: ``, operation: appConfig.method.put
        });

}


async function getContentService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: async (successCb) => {
            const result = await transactionRepo.getContentRepo(req.params.contentName)
            if (result) {
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: !result ? config.response_code.error_dbissue_serverissue : config.response_code.success })
                        , cr.bodyCb({ val: result })
                    ),
                })
            } else {
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.not_found })
                    ),
                })
            }
        }, res: res, errorMessage: appConfig.errorMessage
    });

}

async function getCustomerContentService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await transactionRepo.getCustomerContentRepo()
            const finalResult = result && result.map(details => {
                const apkDetails = new Apk({})
                apkDetails.footer = details.footer
                apkDetails.apkLabel = details.content
                apkDetails.apkLink = details.apk_link
                apkDetails.apkDate = details.last_updated
                return apkDetails
            })
            successResponse({
                successCb: successCb,
                data: finalResult[0]
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.contentService, methodName: appConfig.methodName.getCustomerContentService, userId: ``, operation: ''
    });

}


async function updateCustomerContentService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await transactionRepo.updateCustomerContentRepo(req.body)
            successResponse({
                successCb: successCb,
                data: 'Updated Successfully'
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.contentService, methodName: appConfig.methodName.updateCustomerContentService, userId: ``, operation: appConfig.method.put
    });

}


async function deleteContentService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await transactionRepo.deleteContentRepo(req.params.contentName)

            if (result) {
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: !result ? config.response_code.error_dbissue_serverissue : config.response_code.success })
                    ),
                })
            } else {
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.not_found })
                    ),
                })
            }
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.contentService, methodName: appConfig.methodName.deleteContentService, userId: ``, operation: appConfig.method.delete
    });

}

module.exports = {
    getCustomerContentService,
    addContentService,
    updateContentService,
    getContentService,
    deleteContentService,
    updateCustomerContentService
}
