const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const multipleiprepo = require('../repo/multipleip_repo')
const { successResponse } = require('../service/common_service')
const { validationResult, param } = require('express-validator')
const app_config = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger');
const { timeZoneService } = require('./login_history_service');

function getmultipleIpservice(req, res) {
    const error = validationResult(req);
    if (!error.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, error)
    }
    else {
        cr_handle.handleCommonResponse({successCb:(async (successCb) => {
            const date=timeZoneService(req.query.fromdate,req.query.todate)
            req.query.fromdate=date.fromDate
            req.query.todate=date.toDate
            const results = await multipleiprepo.multipleIpGetBySearchRepo(req.query.ip, req.query.userId, req.query.fromdate, req.query.todate, req.query.parentId)

            logger.infos({ file_name: app_config.fileName.getmultipleIpservice, method_name: app_config.methodName.getmultipleIpservice, userid: `${req.query.parentId}`, operation: app_config.method.get, subOperation: app_config.subOperation.exit, result: app_config.result.success, label: results.length > 0 ? app_config.loggerMessage.data : app_config.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: results,
            })
        }),  res:res, errorMessage:app_config.errorMessage,fileName:app_config.fileName.getmultipleIpservice,methodName:app_config.methodName.getmultipleIpservice,userId:`${req.query.parentId}`,operation:app_config.method.get});
    }
}

module.exports = { getmultipleIpservice }