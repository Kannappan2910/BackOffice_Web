const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const { response_code } = require('@platform_jewels/bassure-node/config/app_conifg.json');
const config_app = require('../config/app_config.json')


function successResponse({ successCb, data }) {
    if (data) {
        if (data.length == 0) { 
            successCb({
                data: cr.responseCb(
                    cr.headerCb({ code: response_code.no_data_found }),
                    cr.bodyCb({ val: config_app.response_messages.noDataFound })
                ),
            });
        } else {
            successCb({
                data: cr.responseCb(
                    cr.headerCb({ code: response_code.success })
                    , cr.bodyCb({ val: data })
                ),
            });
        }
    } else {
        successCb({
            data: cr.responseCb(
                cr.headerCb({ code: response_code.success })
            ),
        });
    }
}
module.exports = {successResponse}