const { body, validationResult } = require('express-validator');
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const appConfig = require('@platform_jewels/bassure-node/config/app_conifg.json');
const { decode } = require('@platform_jewels/bassure-node/service/token')
const config = require('../config/app_config.json')
const bcrypt = require('bcrypt')
const respTime = require('@platform_jewels/bassure-node/service/responseTime')


async function hashPassword(password, rounds) {
    try {
        return await bcrypt.hash(password, rounds || 12)
    } catch (error) {
        logger.warns({ file_name: config.fileName.hashPassword, method_name: config.methodName.hashPassword, userid: ``, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        logger.errors({ file_name: config.fileName.hashPassword, method_name: config.methodName.hashPassword, userid: ``, operation: config.method.put, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
        
    }

}

async function comparePassword(plainPassword, hashedPassword) {
    try {
        return await bcrypt.compare(plainPassword, hashedPassword);
    } catch (error) {
        logger.warns({ file_name: config.fileName.comparePassword, method_name: config.methodName.comparePassword, userid: ``, operation: config.method.put, subOperation: config.subOperation.persists, result: config.result.success, label: ``, errorcode: appConfig.response_code.error_dbissue_serverissue });
        logger.errors({ file_name: config.fileName.comparePassword, method_name: config.methodName.comparePassword, userid: ``, operation: config.method.put, subOperation: config.subOperation.exit, result: config.result.fail, label: `${error.message}`, errorcode: `` });
    }
}

module.exports = {  hashPassword, comparePassword }
