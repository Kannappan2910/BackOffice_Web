const loginRepo = require('../repo/login_repo')
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const logger = require('@platform_jewels/bassure-node/service/logger')
const appConfig = require('../config/app_config.json')
const respTime = require('@platform_jewels/bassure-node/service/responseTime')
const { body, validationResult } = require('express-validator');
const { successResponse } = require('./common_service')
const { serviceCall } = require('./axios_service');
const { operatorAdminAddRepo, operatorAdminDeleteRepo, operatorAdminGetAllRepo, operatorAdminGetByIdRepo, operatorUpdateRepo, operatorIdListRepo, operatorGetAllIdListRepo, operatorUpdateBalanceRepo, operatorSettleRepo, operatorRiskBalanceRepo, opertorCompetitionData, operatorDeleteRepo } = require('../repo/operator_repo');
const { pub, redis } = require('../repo/redis_connection');
const { hashPassword } = require('./middleware_service');
const { User } = require('../entity/user');
const { getRole } = require('../repo/usermanagement_repo');
const { createUserId, createUserStatus } = require('./redisService');
const { betFairAccountStatementService, betFairBalanceService, primaryOperatorIdService, operatorCompetitionService } = require('../config/app_url');
const { hash } = require('bcrypt');
const { OperatorAdmin } = require('../entity/operatorAdmin');
const { Dashboard } = require('../entity/dashboard');


function operatorAddService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        logger.errors({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAddService, userid: `${req.token.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: '', errorcode: config.response_code.field_validation });
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const userType = await getRole(req.token.userType)

                req.body.token = req.token

                const betFairBalance = await serviceCall({
                    url: `${betFairBalanceService}`,
                    method: appConfig.method.post,
                    body: {
                        userName: req.body.betfairUserName,
                        password: req.body.betfairPassword,
                        appkey: req.body.betfairAppkey
                    },
                    headers: req.headers["authorization"]
                })

                if (betFairBalance && betFairBalance.header.code == 600) {
                    req.body.betfairSessionToken = betFairBalance.body.value.betfairSessionToken
                    req.body.betfairBalance = betFairBalance.body.value.betfairBalance
                    req.body.credit = betFairBalance.body.value.betfairBalance
                    req.body.password = await hash(req.body.password, 12)
                    const operatorDetails = await operatorAdminAddRepo(req, userType)
                    if (operatorDetails.length > 0) {
                        req.body.operatorId = operatorDetails[1].operator_id
                        if (operatorDetails && operatorDetails[0] == 0) {
                            const primaryOperatorId = await serviceCall({
                                url: `${primaryOperatorIdService}`,
                                method: appConfig.operation.create,
                                body: {
                                    userName: req.body.betfairUserName,
                                    password: req.body.betfairPassword,
                                    appKey: req.body.betfairAppkey,
                                    operatorId: req.body.operatorId
                                },
                                headers: req.headers["authorization"]
                            })
                            if (primaryOperatorId && primaryOperatorId.header.code == 600) {
                                pub.publish('OperatorId', req.body.operatorId)
                            } else {
                                logger.errors({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAddService, userid: `${req.token.userId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: primaryOperatorId.body.value, errorcode: primaryOperatorId.header.code });
                                await operatorDeleteRepo(req.body.operatorId)
                                return successCb({
                                    data: cr.responseCb(
                                        cr.headerCb({ code: primaryOperatorId.header.code })
                                        , cr.bodyCb({ val: primaryOperatorId.body.value })
                                    ),
                                });
                            }
                        }
                        const operatorCompetition = await serviceCall({
                            url: `${operatorCompetitionService}/${req.body.operatorId}`,
                            method: appConfig.operation.read,
                            headers: req.headers["authorization"]
                        })
                        if (operatorCompetition && operatorCompetition.header.code == 600) {
                            pub.publish('OperatorId', req.body.operatorId)
                            redis.set("betfair_" + req.body.operatorId + "_appkey", req.body.betfairAppkey)
                            redis.set("betfair_" + req.body.operatorId + "_username", req.body.betfairUserName)
                            redis.set("betfair_" + req.body.operatorId + "_password", req.body.betfairPassword)
                            createUserStatus(userType, req.body.userId, req.body.operatorId, appConfig.userstatus.active)
                            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAddService, userid: `${req.body.operatorId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                            successResponse({
                                successCb: successCb,
                                data: appConfig.response_messages.userAdded
                            })
                        } else {
                            logger.errors({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAddService, userid: `${req.body.operatorId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: operatorCompetition.body.value, errorcode: operatorCompetition.header.code });
                            await operatorDeleteRepo(req.body.operatorId)
                            return successCb({
                                data: cr.responseCb(
                                    cr.headerCb({ code: operatorCompetition.header.code })
                                    , cr.bodyCb({ val: operatorCompetition.body.value })
                                ),
                            });
                        }
                    }

                } else {
                    logger.errors({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAddService, userid: `${req.body.operatorId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: betFairBalance.body.value, errorcode: betFairBalance.header.code });
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: betFairBalance.header.code })
                            , cr.bodyCb({ val: betFairBalance.body.value })
                        ),
                    });

                }
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorAddService, userId: `${req.body.operatorId}`, operation: appConfig.method.post
        });
    }
}


function operatorGetAllService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const userType = await getRole(req.token.userType)
            const operatorGetAll = await operatorAdminGetAllRepo(req.query.userStatus, userType, req.token.userId)
            const operatorDetails = operatorGetAll && operatorGetAll.map((details) => {
                const data = new User({})
                data.adminName = details.admin_name
                data.contactNumber = details.contact_number
                data.operatorName = details.operator_name
                data.userId = details.user_id
                data.operatorId = details.operator_id
                data.balance = details.balance
                return data
            })
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorGetAllService, userid: `${req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: operatorGetAll.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: operatorDetails
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorGetAllService, userId: `${req.token.userId}`, operation: appConfig.method.get
    });
}

function operatorGetByIdService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const operatorGetById = await operatorAdminGetByIdRepo(req.params.userId)
            const operatorDetails = operatorGetById && operatorGetById.map(details => {
                const data = new User({})
                data.operatorId = details.operator_id
                data.operatorName = details.operator_name
                data.adminName = details.admin_name
                data.contactNumber = details.contact_number
                data.addressLine1 = details.address_line_1
                data.addressLine2 = details.address_line_2
                data.city = details.city
                data.postCode = details.post_code
                data.userId = details.user_id
                data.userStatus = details.user_status
                data.balance = details.balance
                data.betfairAppkey = details.betfairappkey
                data.betfairUserName = details.betfairusername
                data.betfairPassword = details.betfairpassword
                return data
            })
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAdminGetByIdService, userid: `${req.params.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: operatorGetById.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: operatorDetails
            })

        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorAdminGetByIdService, userId: `${req.params.userId}`, operation: appConfig.method.get
    });
}

function operatorUpdateService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {

            const result = await operatorUpdateRepo(req.body)
            result && result.map(data => {
                createUserStatus(data.user_type, data.user_id, data.operator_id, data.user_status)
            })
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorAdminGetByIdService, userid: ``, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: result.length > 0 ? appConfig.response_messages.operatorUpdated : result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorAdminGetByIdService, userId: ``, operation: appConfig.method.put
    });
}


//betfair
function operatorIdListService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const list = await operatorIdListRepo(req.params.id)
            if (list && list.length > 0) {
                redis.set('betfair_' + list[0].operator_id + '_appkey', list[0].betfairappkey)
                redis.set('betfair_' + list[0].operator_id + '_username', list[0].betfairusername)
                redis.set('betfair_' + list[0].operator_id + '_password', list[0].betfairpassword)
            }
            // const operatorDetails = list && list.map(details => {
            //     const data = new User({})
            //     data.betfairAppkey = details.betfairappkey
            //     data.betfairPassword = details.betfairpassword
            //     data.betfairUserName = details.betfairusername
            //     return data
            // })
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorIdListService, userid: `${req.params.id}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: list.length > 0 ? list[0] : list
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorIdListService, userId: `${req.params.id}`, operation: appConfig.method.put
    });
}

//go lang
function operatorGetAllIdListService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await operatorGetAllIdListRepo()
            // const operatorDetails = result && result.map(details => {
            //     const data = new User()
            //     data.operatorId = details.operator_id
            //     data.betfairAppkey = details.betfairappkey
            //     data.betfairPassword = details.betfairpassword
            //     data.betfairUserName = details.betfairusername
            //     return data
            // })
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorGetAllIdListService, userid: ``, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorGetAllIdListService, userId: ``, operation: appConfig.method.put
    });
}

function operatorGetAllIdListNewService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await operatorGetAllIdListRepo()
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorIdListService, userid: ``, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorIdListService, userId: ``, operation: appConfig.method.put
    });
}



function operatorGetBalance(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            req.body.operatorId = req.token.operatorId
            const betfairDetails = await operatorIdListRepo(req.body.operatorId)
            const updatedBetFairBalance = await serviceCall({
                url: betFairAccountStatementService,
                method: appConfig.operation.create,
                headers: req.headers["authorization"],
                body: JSON.stringify({
                    date: req.query.date,
                    appkey: betfairDetails[0].betfairappkey,
                    userName: betfairDetails[0].betfairusername,
                    password: betfairDetails[0].betfairpassword
                })
            })
            if (updatedBetFairBalance && updatedBetFairBalance.header.code == 600) {

                const betfairResponse = updatedBetFairBalance.body.value
                const index = betfairResponse.findIndex(id => id.refId == betfairDetails[0].id)

                const finalData = betfairResponse.splice(index + 1, betfairResponse.length - index);

                let final = []
                let add = 0
                let id = 0
                finalData && finalData.map(e => {

                    add = e.amount + add
                    id = e.refId
                })
                final.push({
                    amount: add,
                    refId: id
                })
                logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorGetBalance, userid: `${req.body.operatorId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: finalData.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: `` });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.success })
                        , cr.bodyCb({ val: final })
                    ),
                });
            } else {
                logger.errors({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorGetBalance, userid: `${req.body.operatorId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: updatedBetFairBalance.body.value, errorcode: updatedBetFairBalance.header.code });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: updatedBetFairBalance.header.code })
                        , cr.bodyCb({ val: updatedBetFairBalance.body.value })
                    ),
                });
            }

        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorGetBalance, userId: `${req.body.operatorId}`, operation: appConfig.method.get
    });
}


function operatorUpdateBalance(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            req.body.operatorId = req.token.operatorId
            const result = await operatorUpdateBalanceRepo(req.body)
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorUpdateBalance, userid: `${req.body.operatorId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: result.length > 0 ? appConfig.response_messages.updateBalance : result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorUpdateBalance, userId: `${req.body.operatorId}`, operation: appConfig.method.put
    });

}

function operatorDashBoard(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {

            const operatorGetAll = await operatorIdListRepo(req.token.operatorId)
            if (operatorGetAll.length > 0) {

                const betFairBalance = await serviceCall({
                    url: `${betFairBalanceService}`,
                    method: appConfig.method.post,
                    body: {
                        userName: operatorGetAll[0].betfairusername,
                        password: operatorGetAll[0].betfairpassword,
                        appkey: operatorGetAll[0].betfairappkey
                    },
                    headers: req.headers["authorization"]
                })

                if (betFairBalance && betFairBalance.header.code == 600) {
                    const finalResult = operatorGetAll && operatorGetAll.map(details => {
                        const data = new Dashboard({})
                        data.creditLimit = betFairBalance.body.value.betfairBalance
                        data.availableBalance = details.balance
                        data.uplineBalance = (0).toFixed(2)
                        data.downlineBalance = Math.abs(betFairBalance.body.value.betfairBalance - details.balance).toFixed(2)
                        return data
                    })
                    logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorDashBoard, userid: `${req.token.operatorId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                    successResponse({
                        successCb: successCb,
                        data: finalResult
                    })
                } else {
                    logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorDashBoard, userid: `${req.token.operatorId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: '', label: betFairBalance.body.value, errorcode: betFairBalance.header.code });
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: betFairBalance.header.code })
                            , cr.bodyCb({ val: betFairBalance.body.value })
                        ),
                    });
                }
            } else {
                logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorDashBoard, userid: `${req.token.operatorId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.response_messages.noDataFound, errorcode: config.response_code.no_data_found });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.no_data_found })
                        , cr.bodyCb({ val: appConfig.response_messages.noDataFound })
                    ),
                });
            }
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorDashBoard, userId: `${req.token.operatorId}`, operation: appConfig.method.get
    });

}

function operatorSettle(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            req.body.operatorId = req.token.operatorId
            const result = await operatorSettleRepo(req.body)
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorSettle, userid: `${req.token.operatorId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: result.length > 0 ? appConfig.response_messages.updateBalance : result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorSettle, userId: `${req.token.operatorId}`, operation: appConfig.method.put
    });
}

function operatorRiskBalanceService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            console.log(req.body.operatorBalanceList,"req.body.operatorBalanceList")
            const data = req.body.operatorBalanceList
            let finalResult
            for (const value in data) {
                const result = await operatorRiskBalanceRepo(value, data[value])
                finalResult = result
            }
            logger.infos({ file_name: appConfig.fileName.operatorService, method_name: appConfig.methodName.operatorRiskBalanceService, userid: ``, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: finalResult.length > 0 ? true : false
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.operatorService, methodName: appConfig.methodName.operatorRiskBalanceService, userId: ``, operation: appConfig.method.get
    });

}


module.exports = { operatorGetAllIdListNewService, operatorRiskBalanceService, operatorSettle, operatorGetBalance, operatorDashBoard, operatorUpdateBalance, operatorGetAllIdListService, operatorAddService, operatorGetAllService, operatorGetByIdService, operatorUpdateService, operatorIdListService }


// const updatedBetFairBalance = [
        //     {
        //         "refId": "50425431056",
        //         "itemDate": "2022-08-10T07:56:50.000Z",
        //         "amount": 5000,
        //         "balance": 5000
        //     }, {
        //         "refId": "50425431057",
        //         "itemDate": "2022-08-10T07:56:50.000Z",
        //         "amount": 5001,
        //         "balance": 5000
        //     },
        //     {
        //         "refId": "50425431058",
        //         "itemDate": "2022-08-10T07:56:50.000Z",
        //         "amount": 5001,
        //         "balance": 5000
        //     }
        // ]
