const { validationResult } = require('express-validator')
const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const betslipRepo = require('../repo/betslip_repo')
const { successResponse } = require('../service/common_service')
const appConfig = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger')

function betSlipGetById(req, res) {
    cr_handle.handleCommonResponse({successCb:(async (successCb) => {
        const results = await betslipRepo.betslipGetByIdRepo(req.params.id)
        logger.infos({ file_name: appConfig.fileName.betSlipGetService, method_name: appConfig.methodName.betSlipGetById, userid: `${req.params.id}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: results.length > 0 ? appConfig.loggerMessage.data:appConfig.loggerMessage.noDataFound, errorcode: '' });
        successResponse({
            successCb: successCb,
            data: results.length > 0 ? results[0] : results,
        })
    }), res:res, errorMessage:appConfig.errorMessage,fileName:appConfig.fileName.betSlipGetService,methodName:appConfig.methodName.betSlipGetById,userId:`${req.params.id}`,operation:appConfig.method.get});
}


function updateBetSlip(req, res) {
    const error = validationResult(req)
    return !error.isEmpty()
        ? cr_handle.fieldValidationResponse(res, error)
        : cr_handle.handleCommonResponse({successCb:(async (successCb) => {
            const result = await betslipRepo.betSlipUpdateRepo(req.body)
            logger.infos({ file_name: appConfig.fileName.betSlipGetService, method_name: appConfig.methodName.updateBetSlip, userid: `${req.body.customerId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: result.length > 0 ? appConfig.response_messages.betSlipUpdated : result
            })
        }),  res:res, errorMessage:appConfig.errorMessage,fileName:appConfig.fileName.betSlipGetService,methodName:appConfig.methodName.updateBetSlip,userId:`${req.body.customerId}`,operation:appConfig.method.put});
}





module.exports = { betSlipGetById, updateBetSlip }