const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const logger = require('@platform_jewels/bassure-node/service/logger')
const appConfig = require('../config/app_config.json')
const middlewareService = require('./middleware_service')
const { body, validationResult } = require('express-validator');
const { successResponse } = require('./common_service')
const { User } = require('../entity/user');
const { serviceCall } = require('./axios_service');
const { getRole, addUserCredentialRepo, userDeleteRepo, changePasswordRepo, userGetByIdRepo, userGetAllRepo, updateCredentialsRepo, userSearchByIdRepo, agentAdd, agentUpdate, getAllUser, getAllUserByParent, getAllUserByParentCustomer, deleteBetslipRepo, updateActiveCredentialsRepo, updateInActiveCredentialsRepo, getAllUserOperatorIdRepo, resetPasswordRepo, operatorBalance, operatorSearchByIdRepo, userStatusRepo } = require('../repo/usermanagement_repo');
const { loginUserRepo } = require('../repo/login_repo');
const { createUserStatus } = require('./redisService');
const { redis } = require('../repo/redis_connection');
const { settlementAddService, settlementUpdateService, settlementClosedService, settlementGetAllService, settlementGetByIdService } = require('../config/app_url');
const { operatorGetAllIdListRepo } = require('../repo/operator_repo');
const { addLoginDetails } = require('./login_history_service');

//add user
function userAddService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                try {
                    req.body.token = req.token
                    const userType = await getRole(req.body.token.userType)
                    const credentials = await loginUserRepo(req.body.token.userId)
                    req.token.userType == appConfig.userType.operatorAdmin ? req.body.token.parentId : req.body.token.parentId.push(req.body.token.userId);
                    const id = req.body.token.userType == appConfig.userType.operatorAdmin ? req.body.token.createdBy : req.body.token.userId
                    req.body.createdBy = id
                    let isExists;
                    isExists = await middlewareService.comparePassword(req.body.adminPassword, credentials.rows[0].password)
                    if (isExists) {
                        req.body.operatorId = req.body.token.operatorId;
                        req.body.parentId = req.body.token.parentId
                        let fields = req.body;
                        let { userId, password, createdBy, parentId, operatorId, notes } = fields;
                        password = await middlewareService.hashPassword(password)
                        let details
                        if (req.body.token.userType == appConfig.userType.operatorAdmin) {
                            const balance = await operatorBalance(req.body.token.operatorId)
                            if (balance[0].balance > req.body.credit) {
                                details = await addUserCredentialRepo(userId, password, userType, createdBy, parentId, operatorId, notes)
                            } else {
                                logger.errors({ file_name: appConfig.fileName.usermanagementRepo, method_name: appConfig.methodName.operatorBalance, userid: `${createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: `${appConfig.response_messages.lowbalance}`, errorcode: config.response_code.error_dbissue_serverissue });
                                return successCb({
                                    data: cr.responseCb(
                                        cr.headerCb({ code: config.response_code.error_dbissue_serverissue }),
                                        cr.bodyCb({ val: appConfig.response_messages.lowbalance })
                                    )
                                });
                            }
                        } else {
                            details = await addUserCredentialRepo(userId, password, userType, createdBy, parentId, operatorId, notes)
                        }
                        const userAccountService = await serviceCall({
                            url: settlementAddService,
                            method: appConfig.operation.create,
                            body: req.body,
                            headers: req.headers["authorization"]
                        })
                        if (userAccountService && userAccountService.header.code == config.response_code.success) {
                            if (req.body.token.userType == appConfig.userType.operatorAdmin) {
                                await agentAdd(req.body)
                            }
                            createUserStatus(details.user_type, details.user_id, details.operator_id, appConfig.userstatus.active)
                            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.useraddservice, userid: `${createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: ``, errorcode: `` });
                            successResponse({
                                successCb: successCb,
                                data: appConfig.response_messages.userAdded
                            })
                        } else if (userAccountService.header.code == config.response_code.field_validation) {
                            logger.warns({ file_name: appConfig.fileName.userAddService, method_name: appConfig.methodName.userAddService, userid: `${createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.persists, result: appConfig.result.success, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
                            await userDeleteRepo(req.body.userId, req.body.token.userType)
                            successCb({
                                data: {
                                    header: { code: config.response_code.field_validation },
                                    error: userAccountService.error
                                }
                            })
                        } else {
                            await userDeleteRepo(req.body.userId, req.body.token.userType)
                            logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.useraddservice, userid: `${createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: '', label: ``, errorcode: config.response_code.error_dbissue_serverissue });
                            return successCb({
                                data: cr.responseCb(
                                    cr.headerCb({ code: userAccountService.header.code })
                                    , cr.bodyCb({ val: userAccountService.body.value })
                                ),
                            });
                        }
                        // }
                    } else {
                        logger.warns({ file_name: appConfig.fileName.userAddService, method_name: appConfig.methodName.userAddService, userid: `${req.body.createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.persists, result: appConfig.result.success, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
                        successCb({
                            data: {
                                header: { code: config.response_code.field_validation },
                                error: appConfig.loggerMessage.invalidPassword
                            }
                        })
                    }
                } catch (error) {
                    if (error.code == 23505) {
                        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.useraddservice, userid: `${req.body.createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: config.response_code.duplication, errorcode: config.response_code.duplication });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.duplication })
                                , cr.bodyCb({ val: appConfig.errorMessage.duplication })
                            ),
                        });
                    } else if (error.code == 23514) {
                        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.useraddservice, userid: `${req.body.createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: appConfig.response_messages.lowbalance, errorcode: config.response_code.error_dbissue_serverissue });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.error_dbissue_serverissue }),
                                cr.bodyCb({ val: appConfig.response_messages.lowbalance })
                            )
                        });
                    } else {
                        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.useraddservice, userid: `${req.body.createdBy}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: appConfig.errorMessage.unhandled, errorcode: config.response_code.error_dbissue_serverissue });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.error_dbissue_serverissue })
                                , cr.bodyCb({ val: appConfig.errorMessage.unhandled })
                            ),
                        });
                    }
                }
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.useraddservice, userId: `${req.body.createdBy}`, operation: appConfig.method.post
        });
    }
}
//update user
function userUpdateService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${req.token.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: ``, errorcode: config.response_code.field_validation });
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                try {
                    req.body.token = req.token
                    req.body.operatorId = req.body.token.operatorId;
                    const userType = await getRole(req.body.token.userType)
                    const credentials = await loginUserRepo(req.body.token.userId)
                    let updatedBy = req.body.token.userId
                    const isExists = await middlewareService.comparePassword(req.body.adminPassword, credentials.rows[0].password)
                    if (isExists) {
                        let fields = req.body;
                        let { userId, userStatus, notes } = fields;
                        if (req.body.userStatus == appConfig.userstatus.active &&( req.body.addedCredit > 0 || req.body.addedCredit < 0)) {
                            const userAccount = await serviceCall({
                                url: settlementUpdateService,
                                method: appConfig.operation.put,
                                headers: req.headers["authorization"],
                                body: req.body
                            })
                            if (userAccount && userAccount.header.code == 600) {
                                if (req.body.token.userType == appConfig.userType.operatorAdmin) {
                                    await agentUpdate(req.body)
                                }
                                const details = await updateActiveCredentialsRepo(userId, userStatus, notes, updatedBy)
                                createUserStatus(details.user_type, details.user_id, details.operator_id, appConfig.userstatus.active)
                                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: ``, errorcode: `` });
                                successResponse({
                                    successCb: successCb,
                                    data: appConfig.response_messages.userUpdated
                                })
                            } else if (userAccount.header.code == 601) {
                                logger.warns({ file_name: appConfig.fileName.userAddService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.persists, result: appConfig.result.success, label: userAccount.error, errorcode: config.response_code.field_validation });
                                successCb({
                                    data: {
                                        header: { code: config.response_code.field_validation },
                                        error: userAccount.error
                                    }
                                })
                            } else {
                                logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: ``, errorcode: config.response_code.error_dbissue_serverissue });
                                return successCb({
                                    data: cr.responseCb(
                                        cr.headerCb({ code: userAccount.header.code })
                                        , cr.bodyCb({ val: userAccount.body.value })
                                    ),
                                });
                            }
                        }
                        if (req.body.userStatus == appConfig.userstatus.inactive) {
                            const userType = await getRole(req.body.token.userType)
                            const details = await updateInActiveCredentialsRepo(userId, userStatus, notes, updatedBy)
                            createUserStatus(userType, req.body.userId, req.body.token.operatorId, appConfig.userstatus.inactive)
                            details && details.map(detail => {
                                createUserStatus(detail.user_type, detail.user_id, detail.operator_id, appConfig.userstatus.inactive)
                            })
                            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: ``, errorcode: `` });
                            successResponse({
                                successCb: successCb,
                                data: appConfig.response_messages.userUpdated
                            })
                        }
                        if (req.body.userStatus == appConfig.userstatus.closed) {
                            const settlementCheck = await serviceCall({
                                url: settlementClosedService,
                                method: appConfig.operation.create,
                                headers: req.headers["authorization"],
                                body: req.body
                            })
                            if (settlementCheck && settlementCheck.header.code == 600) {
                                if (settlementCheck.body.value) {
                                    const details = await updateInActiveCredentialsRepo(userId, userStatus, notes, updatedBy)
                                    createUserStatus(userType, req.body.userId, req.body.token.operatorId, appConfig.userstatus.inactive)
                                    details && details.map(detail => {
                                        createUserStatus(detail.user_type, detail.user_id, detail.operator_id, appConfig.userstatus.closed)
                                    })
                                    logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                                    successResponse({
                                        successCb: successCb,
                                        data: appConfig.response_messages.userUpdated
                                    })
                                } else {
                                    logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: appConfig.response_messages.closed, errorcode: config.response_code.error_dbissue_serverissue });
                                    return successCb({
                                        data: cr.responseCb(
                                            cr.headerCb({ code: config.response_code.error_dbissue_serverissue })
                                            , cr.bodyCb({ val: appConfig.response_messages.closed })
                                        ),
                                    });
                                }
                            }
                        }
                        if (req.body.userStatus == appConfig.userstatus.betlocked) {
                            const details = await updateActiveCredentialsRepo(userId, userStatus, notes, updatedBy)
                            createUserStatus(details.user_type, details.user_id, details.operator_id, appConfig.userstatus.betlocked)
                            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                            successResponse({
                                successCb: successCb,
                                data: appConfig.response_messages.userUpdated
                            })
                        }
                    } else {
                        successCb({
                            data: {
                                header: { code: config.response_code.field_validation },
                                error: appConfig.loggerMessage.invalidPassword
                            }
                        })
                    }
                } catch (error) {
                    if (error.code == 23514) {
                        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${req.token.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: appConfig.response_messages.lowbalance, errorcode: config.response_code.error_dbissue_serverissue });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.error_dbissue_serverissue }),
                                cr.bodyCb({ val: appConfig.response_messages.lowbalance })
                            )
                        });
                    }
                    else {
                        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userupdateservice, userid: `${req.token.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: appConfig.errorMessage.unhandled, errorcode: config.response_code.error_dbissue_serverissue });
                        return successCb({
                            data: cr.responseCb(
                                cr.headerCb({ code: config.response_code.error_dbissue_serverissue })
                                , cr.bodyCb({ val: appConfig.errorMessage.unhandled })
                            ),
                        });
                    }
                }

            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.userupdateservice, userId: `${req.token.userId}`, operation: appConfig.method.put
        });
    }
}
//user getall
function userGetAllService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            req.body.token = req.token
            let createdBy;
            let userType;
            if (req.query.userId) {
                createdBy = req.query.userType == appConfig.userType.operatorAdmin ? req.body.token.operatorId : req.query.userId
                userType = await getRole(req.query.userType);
            } else {
                userType = await getRole(req.body.token.userType);
                createdBy = req.body.token.userType == appConfig.userType.operatorAdmin ? req.body.token.operatorId : req.body.token.userId
            }
            const userDetails = await userGetAllRepo(req.query.userStatus, createdBy, userType)
            const childRole = userType == appConfig.userType.customer ? '' : await getRole(userType)
            if (userDetails.length > 0) {
                const userBalance = await serviceCall({
                    url: `${settlementGetAllService}?parentId=${createdBy}&userType=${userType}`,
                    method: appConfig.operation.read,
                    headers: req.headers["authorization"]
                })
                const arr = []
                if (userBalance && userBalance.header.code == 600) {
                    userDetails && userDetails.map((data) => {
                        userBalance && userBalance.body.value.map(transaction => {
                            if (transaction.userId == data.user_id) {
                                const obj = { ...data, ...transaction }
                                arr.push(obj)
                            }
                        })
                    })
                    const finalResult = arr.map(data => {
                        const userGetAllDetails = new User({})
                        userGetAllDetails.userId = data.user_id
                        userGetAllDetails.userStatus = data.user_status
                        userGetAllDetails.initialLogin = data.initial_login
                        userGetAllDetails.userType = data.user_type
                        userGetAllDetails.balance = parseFloat(data.balance).toFixed(2)
                        userGetAllDetails.take = parseFloat(data.take).toFixed(2)
                        userGetAllDetails.give = parseFloat(data.give).toFixed(2)
                        userGetAllDetails.credit = data.credit
                        userGetAllDetails.exposure = data.exposure
                        userGetAllDetails.netExposure = data.liable
                        userGetAllDetails.userTypeLabel = appConfig.usertype[data.user_type]
                        userGetAllDetails.childRole = childRole ? appConfig.usertype[childRole] : ''
                        return userGetAllDetails
                    })
                    logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetallservice, userid: `${req?.query?.userId ? req.query.userId : req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                    successResponse({
                        successCb: successCb,
                        data: finalResult
                    })
                } else {
                    logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetallservice, userid: `${req?.query?.userId ? req.query.userId : req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: `${userBalance.body.value}`, errorcode: config.response_code.error_dbissue_serverissue });
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: userBalance.header.code }),
                            cr.bodyCb({ val: userBalance.body.value })
                        )
                    });
                }
            } else {
                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetallservice, userid: `${req?.query?.userId ? req.query.userId : req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: `${appConfig.response_messages.noDataFound}`, errorcode: `${config.response_code.no_data_found}` });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.no_data_found }),
                        cr.bodyCb({ val: appConfig.response_messages.noDataFound })
                    )
                });
            }
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.usergetallservice, userId: `${req.query.userId ? req.query.userId : req.token.userId}`, operation: appConfig.method.get
    });
}

//user get by id
function userGetByIdService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const userDetails = await userGetByIdRepo(req.params.userId)
            const childRole = userDetails[0].user_type == appConfig.userType.customer ? '' : await getRole(userDetails[0].user_type)
            if (userDetails.length > 0) {
                const userBalance = await serviceCall({
                    url: `${settlementGetByIdService}/${req.params.userId}/${userDetails[0].user_type}`,
                    method: appConfig.operation.read,
                    headers: req.headers["authorization"]
                })
                if (userBalance && userBalance.header.code == 600) {

                    let result = userDetails && userDetails.map(data => {
                        const userGetById = new User({})
                        userGetById.userId = data.user_id
                        userGetById.userStatus = data.user_status
                        userGetById.initialLogin = data.initial_login
                        userGetById.userType = data.user_type
                        userGetById.balance = parseFloat(userBalance.body.value[0].balance).toFixed(2)
                        userGetById.credit = userBalance.body.value[0].credit
                        userGetById.smaMaxCredit = userBalance.body.value[0].smaMaxCredit
                        userGetById.maMaxCredit = userBalance.body.value[0].maMaxCredit
                        userGetById.take = parseFloat(userBalance.body.value[0].take).toFixed(2)
                        userGetById.give = parseFloat(userBalance.body.value[0].give).toFixed(2)
                        userGetById.agentMaxCredit = userBalance.body.value[0].agentMaxCredit
                        userGetById.customerMaxCredit = userBalance.body.value[0].customerMaxCredit
                        userGetById.exposure = userBalance.body.value[0].exposure
                        userGetById.netExposure = userBalance.body.value[0].liable
                        userGetById.childRole = childRole
                        userGetById.notes = data.notes
                        return userGetById
                    })
                    logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetbyidservice, userid: `${req.params.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: result.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: `` });
                    successResponse({
                        successCb: successCb,
                        data: result
                    })
                } else {
                    logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetbyidservice, userid: `${req.params.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: `${userBalance.body.value}`, errorcode: config.response_code.error_dbissue_serverissue });
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: userBalance.header.code }),
                            cr.bodyCb({ val: userBalance.body.value })
                        )
                    });
                }

            } else {
                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usergetbyidservice, userid: `${req.params.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.response_messages.noDataFound, errorcode: config.response_code.no_data_found });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.no_data_found }),
                        cr.bodyCb({ val: appConfig.response_messages.noDataFound })
                    )
                });
            }
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.usergetbyidservice, userId: `${req.params.userId}`, operation: appConfig.method.get
    });
}
//delete user
function userDeleteService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {

            const result = await userDeleteRepo(req.query.userId)
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.userdeleteservice, userid: `${req.query.userId}`, operation: appConfig.method.delete, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: result.length > 0 ? appConfig.loggerMessage.deleteMessage : appConfig.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: result.length > 0 ? false : result
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.userdeleteservice, userId: `${req.query.userId}`, operation: appConfig.method.delete
    });
}

function changePasswordService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                let fields = req.body;
                let { userId, oldPassword, newPassword } = fields;
                console.log(req.body, 'req.body');
                const user = await loginUserRepo(userId)
                let isExists = await middlewareService.comparePassword(oldPassword, user.rows[0].password)
                if (!isExists) {
                    return successCb({
                        data: cr.responseCb(
                            cr.headerCb({ code: config.response_code.no_data_found }),
                            cr.bodyCb({ val: appConfig.response_messages.misMatchPassword })
                        )
                    });
                }
                newPassword = await middlewareService.hashPassword(newPassword, 12)
                const result = await changePasswordRepo(userId, newPassword)
                addLoginDetails(req, appConfig.auditTypes.ChangePassword, req.token.createdBy, req.token.userType)
                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.changepasswordservice, userid: `${req.body.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                successResponse({
                    successCb: successCb,
                    data: result.rowCount > 0 ? appConfig.response_messages.password : result
                })
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.changepasswordservice, userId: `${req.body.userId}`, operation: appConfig.method.put
        });
    }
}

function resetPasswordService(req, res) {
    const validationError = validationResult(req)
    if (!validationError.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, validationError)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {

                let fields = req.body;
                let { userId, newPassword } = fields;
                newPassword = await middlewareService.hashPassword(newPassword, 12)
                const result = await resetPasswordRepo(userId, newPassword)
                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.resetPasswordService, userid: `${req.body.userId}`, operation: appConfig.method.put, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                successResponse({
                    successCb: successCb,
                    data: result.rowCount > 0 ? appConfig.response_messages.password : result
                })
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.resetPasswordService, userId: `${req.body.userId}`, operation: appConfig.method.put
        });
    }
}

function userSearchByIdService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            let searchDetails
            if (req.token.userType == appConfig.userType.operatorAdmin && req.token.userId == req.query.parentId) {
                const userType = await getRole(req.token.userType)
                const userId = req.token.operatorId
                searchDetails = await operatorSearchByIdRepo(req.query.by, userId, req.query.userStatus, userType)
            } else {
                const parentId = req.token.userType == appConfig.userType.platformAdmin ? appConfig.userType.operatorAdmin : req.query.parentId
                searchDetails = await userSearchByIdRepo(req.query.by, parentId, req.query.userStatus)
            }
            let usersDetails = searchDetails.map((userDetail) => {
                let userSearchDetails = new User({})
                userSearchDetails.userId = userDetail.user_id
                return userSearchDetails
            })
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usersearchbyidservice, userid: `${req.query.parentId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: searchDetails.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: usersDetails
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.usersearchbyidservice, userId: `${req.query.parentId}`, operation: appConfig.method.get
    });
}

function userSearchByIdParentService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const parentId = req.token.userType == appConfig.userType.operatorAdmin ? req.token.operatorId : req.token.userId
            let searchDetails = await getAllUserByParent(req.query.by, parentId)
            let usersDetails = searchDetails.map((userDetail) => {
                let userSearchDetails = new User({})
                userSearchDetails.userId = userDetail.user_id
                return userSearchDetails
            })
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usersearchbyidparentservice, userid: `${req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: searchDetails.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: usersDetails
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.usersearchbyidparentservice, userId: `${req.token.userId}`, operation: appConfig.method.get
    });
}

function userSearchByIdParentCustomerService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            let searchDetails = await getAllUserByParentCustomer(req.query.by, req.query.parentId)
            let usersDetails = searchDetails.map((userDetail) => {
                let userSearchDetails = new User({})
                userSearchDetails.userId = userDetail.user_id
                return userSearchDetails
            })
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.usersearchbyidparentcustomerservice, userid: `${req.token.parentId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: searchDetails.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: usersDetails
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.usersearchbyidparentcustomerservice, userId: `${req.token.parentId}`, operation: appConfig.method.get
    });
}

function passwordVerifyService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const credentials = await loginUserRepo(req.token.userId)
            const isExists = await middlewareService.comparePassword(req.body.adminPassword, credentials.rows[0].password)
            if (isExists) {
                logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.passwordverifyservice, userid: `${req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                return successCb({
                    data: cr.responseCb(
                        cr.headerCb({ code: config.response_code.success })
                    ),
                });
            } else {
                logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.passwordverifyservice, userid: `${req.token.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: '', errorcode: `${config.response_code.field_validation}` });
                successCb({
                    data: {
                        header: { code: config.response_code.field_validation },
                        error: appConfig.loggerMessage.invalidPassword
                    }
                })
            }
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.passwordverifyservice, userId: `${req.token.userId}`, operation: appConfig.method.get
    });
}

//dropdown userstatus
function dropDownService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const dropdown = req.token.userType == appConfig.userType.platformAdmin ? appConfig.status.OperatorAdmin : req.token.userType == appConfig.userType.agent ? appConfig.status.Customer : appConfig.status.Agent
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.dropDownService, userid: ``, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            return successCb({
                data: cr.responseCb(
                    cr.headerCb({ code: config.response_code.success })
                    , cr.bodyCb({ val: dropdown })
                ),
            });
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.dropDownService, userId: ``, operation: appConfig.method.get
    });
}

// user status
function statusCheckService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await userStatusRepo(req.token.userId)
            redis.set(result.user_type + "_" + result.user_id + "_" + result.operator_id, result.user_status)
            logger.infos({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.statusCheckService, userid: ``, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            return successCb({
                data: cr.responseCb(
                    cr.headerCb({ code: result.user_status == appConfig.userstatus.active || result.user_status == appConfig.userstatus.betlocked ? config.response_code.success : config.response_code.not_found })
                    , cr.bodyCb({ val: result.user_status })
                ),
            });
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.usermanagementService, methodName: appConfig.methodName.statusCheckService, userId: ``, operation: appConfig.method.get
    });
}

//to set values from db to redis
async function redisUserStatus() {
    try {
        const operatorId = await operatorGetAllIdListRepo()
        operatorId && operatorId.map(async (id) => {
            const result = await getAllUserOperatorIdRepo(id.operator_id)
            result && result.map(data => {
                redis.set(`${data.user_type}_${data.user_id}_${data.operator_id}`, data.user_status)
            })

        })
    } catch (error) {
        logger.errors({ file_name: appConfig.fileName.usermanagementService, method_name: appConfig.methodName.redisUserStatus, userid: ``, operation: ``, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label: `${error.message}`, errorcode: `${config.response_code.error_dbissue_serverissue}` });
    }
}

module.exports = { statusCheckService, resetPasswordService, redisUserStatus, userSearchByIdParentService, userSearchByIdParentCustomerService, dropDownService, passwordVerifyService, userAddService, changePasswordService, userSearchByIdService, userGetByIdService, userGetAllService, userDeleteService, userUpdateService }
