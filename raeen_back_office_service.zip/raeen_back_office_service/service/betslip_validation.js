const { body ,validationResult} = require("express-validator")
const logger = require('@platform_jewels/bassure-node/service/logger')
const {operation,subOperation, result, validation_error} = require('../config/app_config.json')
const {stack} = require('../config/regex')
const {fileName, methodName, validate} = require('../config/app_config.json')
const configApp = require('@platform_jewels/bassure-node/config/app_conifg.json')
let id;


function validateBetslipValues() {
    return [   
        body(validate.stack1).custom( (val) =>{
                if (!(stack.test(val))) {
                    logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                    throw new Error(validation_error.credits);
                }
                return true;
            }), 
        body(validate.stack2).custom( (val)  => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }),
         body(validate.stack3).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }), 
        body(validate.stack4).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }), 
        body(validate.plus1).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }), 
        body(validate.plus2).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }), 
        body(validate.plus3).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });

                throw new Error(validation_error.credits);
            }
            return true;
        }), 
        body(validate.plus4).custom((val) => {
            if (!(stack.test(val))) {
                logger.warns({ file_name: fileName.customerService, method_name: methodName.validateBetslipValues, userid: `${id}`, operation: operation.update, suboperation: subOperation.validation, result: result.fail, label: validation_error.credits, errorcode: configApp.response_code.field_validation });
                throw new Error(validation_error.credits);
            }
            return true;
        })
    ]
}



module.exports = { validateBetslipValues }