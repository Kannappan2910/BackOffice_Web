const { body } = require("express-validator");
const { validation_error, validate, columnName, operation, fileName, methodName, subOperation, result } = require('../config/app_config.json')
const { response_code } = require('@platform_jewels/bassure-node/config/app_conifg.json')
const { operatorName, contactNumber, address1, address2, city, postCode, name, userId, passwords, appkey, adminName } = require('../config/regex')
const logger = require('@platform_jewels/bassure-node/service/logger')
let id;
let operations;

function operatorValidation() {
    return [
        body("betfairAppkey").custom((val) => {
            if (!(appkey.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.appkey);
            }
            return true;
        }),
        body("betfairUserName").custom((val) => {
            if (!(userId.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.username);
            }
            return true;
        }),
        body("betfairPassword").custom((val) => {
            if ((!(passwords.test(val)))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.Betfairpassword);
            }
            return true;
        }),
        body(validate.userId).custom((val) => {
            if (!(userId.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.userId);
            }
            return true;
        }),
        body(columnName.password).custom((val,data) => {
            const userId = data.req.body.userId
            if (val.includes(userId)) {
                throw new Error(validation_error.passwordMessage)
            }
            if ((!(passwords.test(val)))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.password);
            }
            return true;
        }),
        body(validate.adminName).custom((val) => {
            if (!(adminName.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.adminName);
            }
            return true;
        }),
        body(validate.operatorName).optional().custom((val, val1) => {
            operations = val1.req.method
            id = val1.req.body.updatedBy || val1.req.body.createdBy
            if (!(adminName.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.firstName, errorcode: response_code.field_validation });
                throw new Error(validation_error.operatorName);
            }
            return true;
        }),
        body(validate.contactNumber).optional().custom((val) => {
            if (!(contactNumber.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.contactNumber);
            }
            return true;
        }),
        body(validate.addressLine1).optional().custom((val) => {
            if (!(address1.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.address);
            }
            return true;
        }),
        body(validate.addressLine2).optional().custom((val) => {
            if (!(address2.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.address);
            }
            return true;
        }),
        body(columnName.city).optional().custom((val) => {
            if (!(city.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.city);
            }
            return true;
        }),
        body(validate.postCode).optional().custom((val) => {
            if (!(postCode.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.postCode);
            }
            return true;
        })
    ]

}

function operatorUpdateValidation() {
    
    return [
      
        
        body(validate.operatorId).custom((val) => {
            if (!(operatorId.test(val)) || val == undefined) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.userId);
            }
            return true;
        }),
      
        body(validate.operatorName).optional().custom((val, val1) => {
            operations = val1.req.method
            id = val1.req.body.updatedBy || val1.req.body.createdBy
            if (!(adminName.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.firstName, errorcode: response_code.field_validation });
                throw new Error(validation_error.operatorName);
            }
            return true;
        }),
        body(validate.contactNumber).optional().custom((val) => {
            if (!(contactNumber.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.contactNumber);
            }
            return true;
        }),
        body(validate.addressLine1).optional().custom((val) => {
            if (!(address1.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.address);
            }
            return true;
        }),
        body(validate.addressLine2).optional().custom((val) => {
            if (!(address2.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.address);
            }
            return true;
        }),
        body(columnName.city).optional().custom((val) => {
            if (!(city.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.city);
            }
            return true;
        }),
        body(validate.postCode).optional().custom((val) => {
            if (!(postCode.test(val))) {
                logger.warns({ file_name: fileName.operatorAdminService, method_name: methodName.operatorValidation, userId: `${id}`, operation: operations, subOperation: subOperation.validation, result: result.fail, label: validation_error.contactNumber, errorcode: response_code.field_validation });
                throw new Error(validation_error.postCode);
            }
            return true;
        })
    ]

}


module.exports = {
    operatorValidation, operatorUpdateValidation
  
}
