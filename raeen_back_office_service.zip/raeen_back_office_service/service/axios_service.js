const { handleError } = require('@platform_jewels/bassure-node/service/errorHandler');
const axios = require('axios')
const appConfig = require('../config/app_config.json')
const logger = require('@platform_jewels/bassure-node/service/logger')
const config = require('@platform_jewels/bassure-node/config/app_conifg.json')

async function serviceCall({ url, method, headers, body }) {
    try {
        let response = await axios({
            url: url,
            method: method,
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "authorization": `${headers}`
            },
            data: body
        });
        return await response.data;
    }
    catch (error) {
        logger.errors({ file_name:appConfig.fileName.axiosService , method_name: appConfig.methodName.serviceCall, userid: ``, operation: appConfig.operation.read, subOperation: appConfig.subOperation.exit, result: appConfig.result.fail, label:  error.message.includes('ECONNREFUSED','ENOTFOUND') ? 'Server Down' : error.message, errorcode: config.response_code.error_dbissue_serverissue })
    }
}


module.exports = { serviceCall }