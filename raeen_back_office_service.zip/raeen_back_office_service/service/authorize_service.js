const { decode } = require('@platform_jewels/bassure-node/service/token');
const {redis} = require('../repo/redis_connection')
const cr = require('@platform_jewels/bassure-node/entity/common_respone')


async function authorize(req, res, next) {
    let permission;
    let mobileToken = req.headers["authorization"];
    let token = mobileToken.split(" ")[1];
    let link = req?._parsedOriginalUrl?.pathname || req.originalUrl
    let originalUrl = req.originalUrl;
    if (originalUrl.includes('?')) {
        //queryparam
        let queryUrl = originalUrl.split('?')[0];
        permission = await redis.get(queryUrl);
    } else {
        //request body
        permission = await redis.get(originalUrl)
        if (!permission) {
            // path param
            let url
            let urlArray = originalUrl.split('/');
            let updatedUrl = urlArray.slice(0, urlArray.length - 1);
            url = updatedUrl.join('/');
            permission = await redis.get(url);
            
        }
    }
    const userDetail = decode(token)
    const role = userDetail.role
    let permissionList = await redis.get(role)
    if (permissionList.includes(permission)) {
        next();
    } else {
        res.set("Connection", "close").send(
            cr.responseCb(
                cr.headerCb({ code: 608 })
            )
        );
    }
}


module.exports = { authorize }