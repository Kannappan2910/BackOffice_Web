const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const logger = require('@platform_jewels/bassure-node/service/logger')
const config_app = require('../config/app_config.json')
const { validationResult, param } = require('express-validator');
const HistoryRepo = require('../repo/login_history_repo')
const moment = require('moment')
const { successResponse } = require('./common_service')
const appConfig = require('../config/app_config.json')
const LoginAudit = require('../entity/loginAudit')
const satelize = require('satelize')
const momenttz = require('moment-timezone')


async function addLoginDetails(req, auditType, createdBy, userType) {
    let ip = req.header('x-real-ip');
    await HistoryRepo.historyRepo(req.body, ip, auditType, createdBy, userType)
}
//login history get by id
function getLoginDetailsById(req, res) {
    const error = validationResult(req);
    if (!error.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, error)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const getResult = await HistoryRepo.getAuditRepo(req.params.userId)

                let ip = req.header('x-real-ip');
                let getByIdLoginHistoryDetails = getResult.map(data => {
                    const loginDate = timeZone(ip, data.date)
                    let details = new LoginAudit.LoginAudit({})
                    details.userId = data.user_id
                    details.parentId = data.parent_id
                    details.Date = loginDate
                    details.ip = data.ip
                    details.auditType = data.audit_type
                    return details
                })
                logger.infos({ file_name: appConfig.fileName.loginHistoryService, method_name: appConfig.methodName.getLoginDetailsById, userid: `${req.params.userId}`, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: getResult.length > 0 ? appConfig.loggerMessage.data : appConfig.loggerMessage.noDataFound, errorcode: `` });
                successResponse({
                    successCb: successCb,
                    data: getByIdLoginHistoryDetails
                })
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.loginHistoryService, methodName: appConfig.methodName.getLoginDetailsById, userId: `${req.params.userId}`, operation: appConfig.method.get
        });
    }
}
//login history getall
function getAllLoginDetails(req, res) {
    const error = validationResult(req)
    if (!error.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, error)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const parentId = req.token.userType == appConfig.userType.operatorAdmin ? req.token.operatorId : req.body.parentId
                let getAllResult
                const dateTime = timeZoneService(req.body.fromdate, req.body.todate)
                req.body.fromdate = dateTime.fromDate
                req.body.todate = dateTime.toDate
                if (req.token.userType == appConfig.userType.operatorAdmin) {
                    getAllResult = await HistoryRepo.getAllAuditOperatorRepo(req.body, parentId)
                } else {
                    getAllResult = await HistoryRepo.getAllAuditRepo(req.body, parentId);
                }
                let ip = req.header('x-real-ip');
                let getAllLoginHistoryDetails = getAllResult.map(data => {
                    const loginDate = timeZone(ip, data.date)
                    let details = new LoginAudit.LoginAudit({})
                    details.userId = data.user_id
                    details.parentId = data.parent_id
                    details.Date = loginDate
                    details.ip = data.ip
                    details.auditType = data.audit_type
                    return details
                })
                logger.infos({ file_name: appConfig.fileName.loginHistoryService, method_name: appConfig.methodName.getAllLoginDetails, userid: `${req.body.parentId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: getAllLoginHistoryDetails.length > 0 ? appConfig.result.success : appConfig.response_messages.noDataFound, errorcode: `` });
                successResponse({
                    successCb: successCb,
                    data: getAllLoginHistoryDetails
                })
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.loginHistoryService, methodName: appConfig.methodName.getAllLoginDetails, userId: req.body.parentId, operation: appConfig.method.post
        });
    }
}
//loginType dropdown
function loginTypeDropDown(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            logger.infos({ file_name: appConfig.fileName.loginHistoryService, method_name: appConfig.methodName.loginTypeDropDown, userid: ``, operation: appConfig.method.get, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
            successResponse({
                successCb: successCb,
                data: appConfig.auditTypeDropdown
            })
        }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.loginHistoryService, methodName: appConfig.methodName.loginTypeDropDown, userId: ``, operation: appConfig.method.get
    });
}

//get all by child role
function getAllLoginChildDetails(req, res) {
    const error = validationResult(req)
    if (!error.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, error)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                const dateTime = timeZoneService(req.body.fromdate, req.body.todate)
                req.body.fromdate = dateTime.fromDate
                req.body.todate = dateTime.toDate

                const getAllResult = await HistoryRepo.getAllAuditChildRepo(req.body);

                let ip = req.header('x-real-ip');
                let getAllLoginHistoryDetails = getAllResult.map(data => {
                    const loginDate = timeZone(ip, data.date)
                    let details = new LoginAudit.LoginAudit({})
                    details.userId = data.user_id
                    details.parentId = data.parent_id
                    details.Date = loginDate
                    details.ip = data.ip
                    details.auditType = data.audit_type
                    return details
                })
                logger.infos({ file_name: appConfig.fileName.loginHistoryService, method_name: appConfig.methodName.getAllLoginChildDetails, userid: `${req.body.parentId}`, operation: appConfig.method.post, subOperation: appConfig.subOperation.exit, result: appConfig.result.success, label: appConfig.loggerMessage.data, errorcode: `` });
                successResponse({
                    successCb: successCb,
                    data: getAllLoginHistoryDetails
                })
            }), res: res, errorMessage: appConfig.errorMessage, fileName: appConfig.fileName.loginHistoryService, methodName: appConfig.methodName.getAllLoginChildDetails, userId: ``, operation: appConfig.method.post
        });
    }
}

function timeZone(ip, time) {
    let timezone;
    if (ip) {
        satelize.satelize({ ip: ip }, function (err, payload) {
            timezone = payload.timezone
        })
    } else {
        timezone = 'Europe/London'
    }
    return momenttz(time).tz(timezone).format('DD/MM/YYYY HH:mm:ss')
}

function timeZoneService(fromdate, todate) {
    let fromDate = fromdate + ' 00:00:00';
    let toDate = todate + ' 23:59:59';
    return { fromDate, toDate };
}


module.exports = { timeZoneService, getAllLoginChildDetails, loginTypeDropDown, addLoginDetails, getLoginDetailsById, getAllLoginDetails }
