const { check } = require("express-validator");

function contentValidation() {
    return [
        check(
            "contentName",
            "ContentName should be a string and should not be empty"
        ).notEmpty()
            .isString(),
        check("contentDetail",
            "ContentDetail should be a string and should not be empty"
        ).notEmpty()
            .isString()
    ];
}

module.exports = {
    contentValidation,
};
