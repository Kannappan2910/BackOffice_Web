const cr_handle = require('@platform_jewels/bassure-node/service/response_handle_service')
const cr = require('@platform_jewels/bassure-node/entity/common_respone');
const config = require('@platform_jewels/bassure-node/config/app_conifg.json');
const surveillancerepo = require('../repo/surveillance_repo')
const { successResponse } = require('../service/common_service')
const logger = require('@platform_jewels/bassure-node/service/logger')
const { validationResult, param } = require('express-validator')
const app_config = require('../config/app_config.json')
const Surveillance = require("../entity/surveillance");
const { redis } = require('../repo/redis_connection');
const { operatorGetAllIdListRepo } = require('../repo/operator_repo');
const moment = require('moment')

//getall
function blockedIpaddressGetByparentIdService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const operatorId = req.token.operatorId
            let results = await surveillancerepo.blockedIpAddressGetByparentIdRepo(req.params.parentId, operatorId)
            let details = results.map(detail => {
                let blockedDetails = new Surveillance.Surveillance({})
                blockedDetails.userId = detail.loginid
                blockedDetails.ipAddress = detail.ip_address
                blockedDetails.deviceId = detail.deviceid
                blockedDetails.comments = detail.comments
                blockedDetails.parentId = detail.parentid
                blockedDetails.blockedDate = moment(detail.blocked_date).format('YYYY-MM-DD')
                blockedDetails.ipStatus = detail.ip_status
                return blockedDetails
            })
            logger.infos({ file_name: app_config.fileName.blockIpAddressService, method_name: app_config.methodName.blockedIpaddressGetByparentIdService, userid: `${req.params.parentId}`, operation: app_config.method.get, subOperation: app_config.subOperation.exit, result: app_config.result.success, label: results.length > 0 ? app_config.loggerMessage.data : app_config.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: details,
            })
        }), res: res, errorMessage: app_config.errorMessage, fileName: app_config.fileName.blockIpAddressService, methodName: app_config.methodName.blockedIpaddressGetByparentIdService, userId: `${req.query.parentId}`, operation: app_config.method.get
    });
}
//search
function searchByIpAddressService(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const operatorId = req.token.operatorId
            let results = await surveillancerepo.searchIpAddressRepo(req.query.ipAddress, req.query.parentId, operatorId)
            let details = results.map(detail => {
                let blockedDetails = new Surveillance.Surveillance({})
                blockedDetails.userId = detail.loginid
                blockedDetails.ipAddress = detail.ip_address
                blockedDetails.deviceId = detail.deviceid
                blockedDetails.comments = detail.comments
                blockedDetails.parentId = detail.parentid
                blockedDetails.blockedDate = moment(detail.blocked_date).format('YYYY-MM-DD')
                blockedDetails.ipStatus = detail.ip_status
                return blockedDetails
            })
            logger.infos({ file_name: app_config.fileName.blockIpAddressService, method_name: app_config.methodName.searchByIpAddressService, userid: `${req.query.parentId}`, operation: app_config.method.get, subOperation: app_config.subOperation.exit, result: app_config.result.success, label: results.length > 0 ? app_config.loggerMessage.data : app_config.loggerMessage.noDataFound, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: details,
            })
        }), res: res, errorMessage: app_config.errorMessage, fileName: app_config.fileName.blockIpAddressService, methodName: app_config.methodName.searchByIpAddressService, userId: `${req.query.parentId}`, operation: app_config.method.get
    });
}

//block
function blockIpAddressService(req, res) {
    const error = validationResult(req)
    if (!error.isEmpty()) {
        return cr_handle.fieldValidationResponse(res, error)
    }
    else {
        cr_handle.handleCommonResponse({
            successCb: (async (successCb) => {
                req.body.parentId = req.token.userType == app_config.userType.operatorAdmin ? req.token.operatorId : req.token.userId
                req.body.operatorId = req.token.operatorId
                const results = await surveillancerepo.addIpAddressRepo(req.body)
                const list = await redis.get(req.token.operatorId + '_BlockedIp') || []
                const arr = list.length == 0 ? [] : JSON.parse(list)
                arr.push(results[0])
                redis.set(req.token.operatorId + '_BlockedIp', JSON.stringify(arr))
                logger.infos({ file_name: app_config.fileName.blockIpAddressService, method_name: app_config.methodName.blockIpAddressService, userid: `${req.token.operatorId}`, operation: app_config.method.post, subOperation: app_config.subOperation.exit, result: app_config.result.success, label: app_config.loggerMessage.data, errorcode: '' });
                successResponse({
                    successCb: successCb,
                    data: app_config.response_messages.blockedSuccesfully
                })
            }), res: res, errorMessage: app_config.errorMessage, fileName: app_config.fileName.blockIpAddressService, methodName: app_config.methodName.blockIpAddressService, userId: `${req.token.operatorId}`, operation: app_config.method.get
        });
    }
}

//unblock
function unBlockIpAddress(req, res) {
    cr_handle.handleCommonResponse({
        successCb: (async (successCb) => {
            const result = await surveillancerepo.unBlockIpAddress(req.params.ipaddress)
            let arr = []
            const data = result && result.map(async (e) => {
                const status = await redis.get(e.operator_id + '_BlockedIp')

                const blockedIp = JSON.parse(status)
                blockedIp && blockedIp.map(ip => {
                    if (e.ip_address != ip.ip_address) {
                        arr.push(ip)
                    }
                })
                redis.set(e.operator_id + '_BlockedIp', JSON.stringify(arr))
            })
            logger.infos({ file_name: app_config.fileName.blockIpAddressService, method_name: app_config.methodName.unBlockIpAddress, userid: ``, operation: app_config.method.delete, subOperation: app_config.subOperation.exit, result: app_config.result.success, label: app_config.loggerMessage.deleteMessage, errorcode: '' });
            successResponse({
                successCb: successCb,
                data: result
            })
        }), res: res, errorMessage: app_config.errorMessage, fileName: app_config.fileName.blockIpAddressService, methodName: app_config.methodName.unBlockIpAddress, userId: ``, operation: app_config.method.delete
    });
}


async function blockedIpAddress() {
    try {
        const operatorId = await operatorGetAllIdListRepo()
        operatorId && operatorId.map(async (id) => {
            const result = await surveillancerepo.getAllIpAddress(id.operator_id)
            redis.set(`${id.operator_id}` + '_BlockedIp', JSON.stringify(result))
        })
    } catch (error) {
        logger.errors({ file_name: app_config.fileName.blockIpAddressService, method_name: app_config.methodName.blockedIpAddress, userid: ``, operation: ``, subOperation: app_config.subOperation.exit, result: app_config.result.fail, label: `${error.message}`, errorcode: `${config.response_code.error_dbissue_serverissue}` });
    }
}


// function unblockByIpAddressService(req, res) {
//     cr_handle.handleCommonResponse(async (successCb) => {

//         var results = await surveillancerepo.unblockByIpAddressRepo(req.params.ipAddress)

//         successResponse({
//             successCb: successCb,
//             data: results.length > 0 ? 'updated Successfully' : results,
//         })
//     }, res, app_config.errorMessage);
//     // 
// }

// function blockByIpAddressService(req, res) {

//     cr_handle.handleCommonResponse(async (successCb) => {
//         var results = await surveillancerepo.blockByIpAddressRepo(req.body)

//         successResponse({
//             successCb: successCb,
//             data: results.length > 0 ? 'updated Successfully' : results,
//         })
//     }, res, app_config.errorMessage);
//     // 
// }


module.exports = { blockedIpAddress, unBlockIpAddress, blockedIpaddressGetByparentIdService, blockIpAddressService, searchByIpAddressService }
